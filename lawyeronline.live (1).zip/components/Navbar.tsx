import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../App';
import { subscribeToAppLogo, DEFAULT_LOGO_SVG } from '../services/mockDataService';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../services/firebase';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);
  
  // Profile Picture State
  const [profilePic, setProfilePic] = useState<string | null>(null);
  const [profileImgError, setProfileImgError] = useState(false);
  
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsProfileDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Subscribe to App Logo changes
  useEffect(() => {
    const unsubscribe = subscribeToAppLogo((url) => {
        setAppLogoUrl(url);
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to User Profile Picture changes (Real-time Sync)
  useEffect(() => {
    if (user) {
        setProfileImgError(false); // Reset error state on user change
        
        if (user.role === 'lawyer' || user.role === 'admin') {
            // For lawyers/admins, listen to their Firestore profile for the latest picture
            const unsub = onSnapshot(doc(db, 'lawyers', user.uid), (docSnap) => {
                if (docSnap.exists()) {
                    const data = docSnap.data();
                    // Use the picture from DB, or fallback to Auth photoURL if DB is empty
                    setProfilePic(data.picture || user.photoURL || null);
                } else {
                    setProfilePic(user.photoURL || null);
                }
            }, (error) => {
                console.error("Profile sync error:", error);
                setProfilePic(user.photoURL || null); // Fallback on error
            });
            return () => unsub();
        } else {
            // For clients, standard auth photo
            setProfilePic(user.photoURL || null);
        }
    } else {
        setProfilePic(null);
    }
  }, [user]);


  const handleLogout = () => {
    logout();
    navigate('/login');
    setIsOpen(false);
    setIsProfileDropdownOpen(false);
  };

  const getDashboardLink = () => {
    if (!user) return '/';
    if (user.role === 'admin' || user.role === 'lawyer') return '/dashboard/lawyer';
    return '/dashboard/client';
  };

  const getInitials = (name?: string) => {
      if (!name) return 'U';
      return name.charAt(0).toUpperCase();
  };

  // Helper component for Waving Text
  const WavyText = ({ text, className, delayStart = 0, colorClass = "text-white" }: { text: string, className: string, delayStart?: number, colorClass?: string }) => (
    <div className={`flex ${className}`}>
      {text.split('').map((char, i) => (
        <span
          key={i}
          className={`animate-wave inline-block ${colorClass}`}
          style={{ animationDelay: `${delayStart + (i * 0.1)}s` }}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </div>
  );

  return (
    <nav className="bg-blue-950 shadow-lg sticky top-0 z-50 font-sans h-20 flex items-center border-b-4 border-amber-500">
      {/* Injecting keyframes locally for the wave animation */}
      <style>{`
        @keyframes wave {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
        }
      `}</style>

      <div className="container mx-auto px-4 w-full">
        <div className="flex justify-between items-center w-full">
          <Link to="/" className="flex items-center space-x-2 group">
            {/* Dynamic Logo or Fallback */}
            {appLogoUrl ? (
                <img 
                    src={appLogoUrl} 
                    alt="LawyerOnline.LIVE Logo" 
                    className="h-14 w-auto object-contain" // Increased logo height
                    onError={(e) => {
                        e.currentTarget.onerror = null; // Prevent loop
                        setAppLogoUrl(null); // Switch to fallback render
                    }}
                />
            ) : (
                 <img 
                    src={DEFAULT_LOGO_SVG} 
                    alt="LawyerOnline.LIVE Logo" 
                    className="h-14 w-auto object-contain" // Increased logo height
                />
            )}
            
            {/* Animated Text Logo */}
            <div className="flex flex-col leading-none">
                <WavyText 
                    text="LawyerOnline" 
                    className="text-lg font-bold tracking-tight" 
                    colorClass="text-white"
                />
                <WavyText 
                    text=".LIVE" 
                    className="text-[10px] font-bold tracking-widest" 
                    delayStart={1.2} // Start waving after the first line finishes a half-cycle
                    colorClass="text-red-500 group-hover:text-red-400 transition-colors"
                />
            </div>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6 text-sm">
            <Link to="/" className="text-blue-100 hover:text-amber-400 font-medium transition">Home</Link>
            <Link to="/find-lawyers" className="text-blue-100 hover:text-amber-400 font-medium transition">Find Lawyers</Link>
            
            {user ? (
              <div className="flex items-center space-x-4">
                {user.role === 'admin' && (
                  <Link 
                    to="/dashboard/admin"
                    className="text-amber-400 font-semibold border border-amber-600 bg-blue-900/50 px-3 py-1 rounded hover:bg-blue-900 transition text-xs uppercase tracking-wider"
                  >
                    Admin Panel
                  </Link>
                )}

                {/* Profile Dropdown */}
                <div className="relative" ref={dropdownRef}>
                    <button 
                        onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                        className="flex items-center space-x-2 focus:outline-none"
                    >
                        <div className="w-12 h-12 rounded-full bg-blue-900 border-2 border-amber-500 text-amber-500 flex items-center justify-center font-bold overflow-hidden text-sm shadow-md hover:shadow-amber-500/50 transition-shadow"> 
                            {profilePic && !profileImgError ? (
                                <img 
                                    src={profilePic} 
                                    alt="Profile" 
                                    className="w-full h-full object-cover" 
                                    onError={() => setProfileImgError(true)} // Graceful fallback
                                />
                            ) : (
                                getInitials(user.displayName)
                            )}
                        </div>
                    </button>

                    {isProfileDropdownOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-xl py-1 border border-slate-100 animate-in fade-in zoom-in duration-200">
                             <div className="px-4 py-2 border-b border-slate-50">
                                <p className="text-sm font-semibold text-slate-800 truncate">{user.displayName || 'User'}</p>
                                <p className="text-xs text-slate-500 truncate">{user.role}</p>
                             </div>
                             <Link 
                                to={getDashboardLink()} 
                                className="block px-4 py-2 text-sm text-slate-700 hover:bg-amber-50 hover:text-amber-700 transition"
                                onClick={() => setIsProfileDropdownOpen(false)}
                            >
                                Dashboard
                            </Link>
                             <button 
                                onClick={handleLogout}
                                className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition"
                            >
                                Logout
                            </button>
                        </div>
                    )}
                </div>

              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link to="/login" className="px-4 py-2 text-blue-100 font-medium hover:text-white transition">
                  Login
                </Link>
                <Link to="/signup" className="px-5 py-2 bg-amber-500 text-blue-950 rounded-lg hover:bg-amber-400 transition shadow-lg font-bold hover:-translate-y-0.5">
                  Sign Up
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white focus:outline-none p-1">
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-blue-950 border-t border-blue-900 absolute top-20 left-0 w-full shadow-2xl z-40">
          <div className="px-4 pt-4 pb-6 space-y-2">
            <Link to="/" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-blue-100 hover:bg-blue-900 hover:text-amber-400 rounded">Home</Link>
            <Link to="/find-lawyers" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-blue-100 hover:bg-blue-900 hover:text-amber-400 rounded">Find Lawyers</Link>
            {user ? (
              <>
                 {user.role === 'admin' && (
                    <Link to="/dashboard/admin" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-amber-400 font-medium hover:bg-blue-900 rounded">Admin Panel</Link>
                 )}
                 <div className="border-t border-blue-900 my-2 pt-3">
                     <div className="px-3 flex items-center mb-3">
                        <div className="w-10 h-10 rounded-full bg-blue-900 border border-amber-500 text-amber-500 flex items-center justify-center font-bold mr-3 text-sm overflow-hidden"> 
                            {profilePic && !profileImgError ? (
                                <img 
                                    src={profilePic} 
                                    alt="Profile" 
                                    className="w-full h-full object-cover" 
                                    onError={() => setProfileImgError(true)} 
                                />
                            ) : (
                                getInitials(user.displayName)
                            )}
                        </div>
                        <span className="font-semibold text-white">{user.displayName}</span>
                     </div>
                     <Link to={getDashboardLink()} onClick={() => setIsOpen(false)} className="block px-3 py-2 text-blue-100 font-medium hover:bg-blue-900 rounded">Go to Dashboard</Link>
                     <button onClick={handleLogout} className="block w-full text-left px-3 py-2 text-red-400 hover:bg-blue-900 rounded">Logout</button>
                 </div>
              </>
            ) : (
              <div className="flex flex-col gap-3 mt-4">
                <Link to="/login" onClick={() => setIsOpen(false)} className="block text-center px-3 py-2 text-blue-100 border border-blue-800 rounded hover:bg-blue-900">Login</Link>
                <Link to="/signup" onClick={() => setIsOpen(false)} className="block text-center px-3 py-2 bg-amber-500 text-blue-950 rounded font-bold hover:bg-amber-400 shadow-md">Sign Up</Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}