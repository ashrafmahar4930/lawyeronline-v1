

import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import * as db from '../services/mockDataService';
import { LawyerProfile, ConsultationLog, Booking } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { getAppLogoUrl, DEFAULT_LOGO_SVG, getBookingsForClient } from '../services/mockDataService';

export default function ClientDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [favoriteLawyers, setFavoriteLawyers] = useState<LawyerProfile[]>([]);
  const [consultationHistory, setConsultationHistory] = useState<ConsultationLog[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadClientData = async () => {
      if (user && user.role === 'client') {
        setIsLoading(true);
        try {
          const favorites = await db.getFavorites(user.uid);
          setFavoriteLawyers(favorites);

          const history = await db.getClientConsultationHistory(user.uid);
          setConsultationHistory(history);

          const clientBookings = await getBookingsForClient(user.uid);
          setBookings(clientBookings);

          const logo = await getAppLogoUrl();
          setAppLogoUrl(logo);

        } catch (error) {
          console.error("Error loading client dashboard data:", error);
        } finally {
          setIsLoading(false);
        }
      } else if (!user) {
        navigate('/login'); // Redirect to login if no user
      }
    };

    loadClientData();
  }, [user, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-80px)] flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        <p className="ml-4 text-slate-600">Loading your dashboard...</p>
      </div>
    );
  }

  if (!user || user.role !== 'client') {
    return <div className="min-h-[calc(100vh-80px)] flex items-center justify-center text-red-500">Access Denied: Not a client or not logged in.</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-slate-900">Client Dashboard</h1>
        {/* Notification Bell (Optional: could be functional later) */}
        <div className="relative cursor-pointer group">
            <svg className="w-8 h-8 text-slate-600 group-hover:text-blue-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
            <span className="absolute top-0 right-0 block h-3 w-3 rounded-full ring-2 ring-white bg-red-500"></span>
        </div>
      </div>
      
      {/* My Appointments Section (New) */}
      <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100 mb-6">
          <h2 className="text-xl font-bold mb-4 text-slate-800 flex items-center gap-2">
            <svg className="w-6 h-6 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            My Appointments
          </h2>
          {bookings.length === 0 ? (
              <p className="text-slate-500 italic py-4">No appointments scheduled.</p>
          ) : (
              <div className="overflow-x-auto">
                  <table className="min-w-full text-left text-sm">
                      <thead className="bg-slate-50 text-slate-500 uppercase font-semibold">
                          <tr>
                              <th className="p-3">Lawyer</th>
                              <th className="p-3">Date</th>
                              <th className="p-3">Time</th>
                              <th className="p-3">Status</th>
                              <th className="p-3">Notes</th>
                          </tr>
                      </thead>
                      <tbody>
                          {bookings.map(book => (
                              <tr key={book.id} className="border-b last:border-0 hover:bg-slate-50">
                                  <td className="p-3 font-medium">{book.lawyerName}</td>
                                  <td className="p-3">{book.date}</td>
                                  <td className="p-3">{book.time}</td>
                                  <td className="p-3">
                                      <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
                                          book.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                                          book.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                          'bg-yellow-100 text-yellow-700'
                                      }`}>
                                          {book.status}
                                      </span>
                                  </td>
                                  <td className="p-3 text-slate-500 truncate max-w-xs">{book.notes}</td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* My Favorites Section */}
          <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100">
              <h2 className="text-xl font-bold mb-4 text-slate-800 flex items-center gap-2">
                <svg className="w-6 h-6 text-red-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                My Favorite Lawyers
              </h2>
              {favoriteLawyers.length === 0 ? (
                  <p className="text-slate-500 italic py-4">You haven't saved any lawyers yet. Find one in <Link to="/find-lawyers" className="text-blue-600 hover:underline">Find Lawyers</Link>!</p>
              ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {favoriteLawyers.map(lawyer => (
                          <Link to={`/lawyer/${lawyer.uid}`} key={lawyer.uid} className="flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors border border-blue-100 shadow-sm">
                              <img 
                                src={lawyer.picture || appLogoUrl || DEFAULT_LOGO_SVG} 
                                alt={lawyer.fullName} 
                                className="w-10 h-10 rounded-full object-cover mr-3 border-2 border-white shadow-sm"
                                onError={(e) => { 
                                    const img = e.currentTarget;
                                    img.onerror = null; // STOP INFINITE LOOP
                                    img.src = DEFAULT_LOGO_SVG; 
                                }}
                              />
                              <div>
                                  <h3 className="font-semibold text-slate-800 text-sm truncate">{lawyer.fullName}</h3>
                                  <p className="text-blue-600 text-xs">{lawyer.title} &bull; {lawyer.specialties?.[0] || 'General'}</p>
                              </div>
                          </Link>
                      ))}
                  </div>
              )}
          </div>

          {/* Consultation History Section */}
          <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100">
              <h2 className="text-xl font-bold mb-4 text-slate-800 flex items-center gap-2">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                Consultation History
              </h2>
              {consultationHistory.length === 0 ? (
                  <p className="text-slate-500 italic py-4">No past consultations or interactions logged.</p>
              ) : (
                  <div className="space-y-3">
                      {consultationHistory.map(log => (
                          <div key={log.id} className="flex items-center p-3 bg-slate-50 rounded-lg border border-slate-100 shadow-sm">
                              <div className="flex-shrink-0 mr-3">
                                  {log.contactMethod === 'whatsapp' && <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>}
                                  {log.contactMethod === 'call' && <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>}
                                  {log.contactMethod === 'email' && <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>}
                                  {log.contactMethod === 'favorite' && <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>}
                              </div>
                              <div className="flex-grow">
                                  <Link to={`/lawyer/${log.lawyerId}`} className="font-semibold text-slate-800 hover:text-blue-600 transition-colors text-sm">{log.lawyerName}</Link>
                                  <p className="text-slate-500 text-xs">Method: <span className="capitalize">{log.contactMethod}</span> &bull; {new Date(log.contactedAt).toLocaleDateString()}</p>
                              </div>
                          </div>
                      ))}
                  </div>
              )}
          </div>
      </div>
    </div>
  );
}