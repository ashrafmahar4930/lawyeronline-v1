import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { LawyerProfile, Case, KhataEntry, VerificationRequest, Country, ImportantDate, CaseFile, Booking } from '../types';
import * as db from '../services/mockDataService';
import { generateLegalDocument } from '../services/geminiService';
import { useNavigate } from 'react-router-dom';
import { compressImage } from '../utils/imageUtils';
import { getAppLogoUrl, DEFAULT_LOGO_SVG, getBookingsForLawyer, updateBookingStatus } from '../services/mockDataService';

// --- Integrated CaseDetailsModal Component ---

interface CaseDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseData: Case;
  onUpdateCase: (updatedCase: Case) => void;
  onDeleteCase: (caseId: string) => void;
  lawyerId: string;
  khataEntries: KhataEntry[];
  onDeleteKhata: (entryId: string) => void;
}

const CaseDetailsModal: React.FC<CaseDetailsModalProps> = ({ isOpen, onClose, caseData, onUpdateCase, onDeleteCase, lawyerId, khataEntries, onDeleteKhata }) => {
  const [editedCase, setEditedCase] = useState<Case>(caseData);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [newImportantDate, setNewImportantDate] = useState<Partial<ImportantDate>>({});

  useEffect(() => {
    setEditedCase(caseData);
  }, [caseData]);

  if (!isOpen) return null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditedCase(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await db.updateCase(editedCase);
      onUpdateCase(editedCase);
      alert("Case updated successfully!");
      onClose();
    } catch (error) {
      console.error("Failed to save case:", error);
      alert("Failed to save case.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteCase = async () => {
    if (window.confirm("Are you sure you want to permanently delete this case and all associated files and khata entries? This cannot be undone.")) {
      try {
        await db.deleteCase(editedCase.id);
        onDeleteCase(editedCase.id);
        alert("Case deleted successfully.");
        onClose();
      } catch (error) {
        console.error("Failed to delete case:", error);
        alert("Failed to delete case.");
      }
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadingFile(true);
      try {
        const originalFile = e.target.files[0];
        const compressedFile = await compressImage(originalFile, 1500, 1500, 0.85); // Moderate compression for case docs

        const path = `case-files/${lawyerId}/${editedCase.id}/${Date.now()}_${compressedFile.name}`;
        const url = await db.uploadFile(compressedFile, path); // No oldFileUrl for new case files

        const newFile: CaseFile = {
          id: `file_${Date.now()}`,
          name: originalFile.name,
          url: url,
          uploadedAt: new Date().toISOString(),
        };
        const updatedCase = { ...editedCase, caseFiles: [...editedCase.caseFiles, newFile] };
        setEditedCase(updatedCase); // Update local state
        await db.updateCase(updatedCase); // Persist immediately
        onUpdateCase(updatedCase); // Update parent state
        alert("File uploaded successfully!");
      } catch (error) {
        console.error("File upload failed:", error);
        alert("File upload failed.");
      } finally {
        setUploadingFile(false);
        e.target.value = ''; // Clear file input
      }
    }
  };

  const handleDeleteFile = async (fileToDelete: CaseFile) => {
    if (window.confirm(`Are you sure you want to delete "${fileToDelete.name}"?`)) {
      try {
        await db.deleteFile(fileToDelete.url);
        const updatedCase = { ...editedCase, caseFiles: editedCase.caseFiles.filter(f => f.id !== fileToDelete.id) };
        setEditedCase(updatedCase); // Update local state
        await db.updateCase(updatedCase); // Persist immediately
        onUpdateCase(updatedCase); // Update parent state
        alert("File deleted successfully!");
      } catch (error) {
        console.error("Failed to delete file:", error);
        alert("Failed to delete file.");
      }
    }
  };

  const handleAddImportantDate = () => {
    if (!newImportantDate.title || !newImportantDate.date) {
      alert("Please enter title and date for the important date.");
      return;
    }
    const dateToAdd: ImportantDate = {
      id: `date_${Date.now()}`,
      title: newImportantDate.title,
      date: newImportantDate.date,
      notes: newImportantDate.notes || '',
    };
    const updatedCase = { ...editedCase, importantDates: [...editedCase.importantDates, dateToAdd] };
    setEditedCase(updatedCase);
    setNewImportantDate({}); // Reset form
  };

  const handleDeleteImportantDate = (dateId: string) => {
    if (window.confirm("Are you sure you want to delete this important date?")) {
      const updatedCase = { ...editedCase, importantDates: editedCase.importantDates.filter(d => d.id !== dateId) };
      setEditedCase(updatedCase);
    }
  };

  // Sort important dates
  const sortedImportantDates = [...editedCase.importantDates].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col">
        {/* Modal Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-slate-900">Edit Case: {caseData.caseTitle}</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-8 flex-grow">
          {/* General Case Details */}
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
            <h3 className="font-bold text-xl mb-4 text-slate-800">General Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Case Title</label>
                <input type="text" name="caseTitle" value={editedCase.caseTitle} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Client Name</label>
                <input type="text" name="clientName" value={editedCase.clientName} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Court Name</label>
                <input type="text" name="courtName" value={editedCase.courtName} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Opposing Counsel / Party</label>
                <input type="text" name="opposingCounsel" value={editedCase.opposingCounsel || ''} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Next Hearing Date</label>
                <input type="date" name="nextHearingDate" value={editedCase.nextHearingDate} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Current Stage</label>
                <select name="stage" value={editedCase.stage} onChange={handleInputChange} className="w-full border p-2 rounded">
                  <option value="Filing">Filing</option>
                  <option value="Hearing">Hearing</option>
                  <option value="Evidence">Evidence</option>
                  <option value="Verdict">Verdict</option>
                  <option value="Appeal">Appeal</option>
                  <option value="Closed">Closed</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">Overall Case Status</label>
                <select name="status" value={editedCase.status} onChange={handleInputChange} className="w-full border p-2 rounded">
                  <option value="Open">Open</option>
                  <option value="On Hold">On Hold</option>
                  <option value="Closed">Closed</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">Short Description / Summary</label>
                <textarea name="description" rows={2} value={editedCase.description || ''} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">Internal Notes</label>
                <textarea name="notes" rows={2} value={editedCase.notes || ''} onChange={handleInputChange} className="w-full border p-2 rounded" />
              </div>
            </div>
          </div>

          {/* Important Dates */}
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
            <h3 className="font-bold text-xl mb-4 text-slate-800">Important Dates</h3>
            <div className="space-y-4 mb-6">
              {sortedImportantDates.length === 0 ? (
                <p className="text-slate-500 italic">No important dates added yet.</p>
              ) : (
                <ul className="space-y-2">
                  {sortedImportantDates.map(date => (
                    <li key={date.id} className="flex justify-between items-center bg-white p-3 rounded-md shadow-sm border border-slate-100">
                      <div>
                        <span className="font-semibold">{date.title}</span> - <span className="text-blue-600">{date.date}</span>
                        {date.notes && <p className="text-xs text-slate-600 italic">{date.notes}</p>}
                      </div>
                      <button onClick={() => handleDeleteImportantDate(date.id)} className="text-red-600 hover:text-red-800 text-sm">Delete</button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="border-t pt-4 mt-4">
              <h4 className="font-semibold text-lg mb-2">Add New Date</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input type="text" placeholder="Title (e.g., Next Hearing)" value={newImportantDate.title || ''} onChange={e => setNewImportantDate(prev => ({ ...prev, title: e.target.value }))} className="border p-2 rounded" />
                <input type="date" value={newImportantDate.date || ''} onChange={e => setNewImportantDate(prev => ({ ...prev, date: e.target.value }))} className="border p-2 rounded" />
                <input type="text" placeholder="Notes (optional)" value={newImportantDate.notes || ''} onChange={e => setNewImportantDate(prev => ({ ...prev, notes: e.target.value }))} className="border p-2 rounded" />
              </div>
              <button onClick={handleAddImportantDate} className="mt-4 bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700">Add Date</button>
            </div>
          </div>

          {/* Case Documents */}
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
            <h3 className="font-bold text-xl mb-4 text-slate-800">Case Documents</h3>
            <div className="space-y-4 mb-6">
              {editedCase.caseFiles.length === 0 ? (
                <p className="text-slate-500 italic">No documents uploaded for this case yet.</p>
              ) : (
                <ul className="space-y-2">
                  {editedCase.caseFiles.map(file => (
                    <li key={file.id} className="flex justify-between items-center bg-white p-3 rounded-md shadow-sm border border-slate-100">
                      <div>
                        <a href={file.url} target="_blank" rel="noreferrer" className="font-semibold text-blue-600 hover:underline">{file.name}</a>
                        <p className="text-xs text-slate-600">Uploaded: {new Date(file.uploadedAt).toLocaleDateString()}</p>
                      </div>
                      <button onClick={() => handleDeleteFile(file)} className="text-red-600 hover:text-red-800 text-sm">Delete</button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="border-t pt-4 mt-4">
              <h4 className="font-semibold text-lg mb-2">Upload New Document</h4>
              <input type="file" onChange={handleFileUpload} className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-600 file:text-white hover:file:bg-green-700" />
              {uploadingFile && <div className="text-xs text-blue-600 mt-1">Uploading...</div>}
            </div>
          </div>

          {/* Khata Entries for this Case */}
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
            <h3 className="font-bold text-xl mb-4 text-slate-800">Khata Entries for This Case</h3>
            {khataEntries.length === 0 ? (
              <p className="text-slate-500 italic">No Khata entries for this case yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="text-slate-500 text-xs uppercase bg-white">
                    <tr>
                      <th className="text-left p-2">Description</th>
                      <th className="text-right p-2">Total</th>
                      <th className="text-right p-2">Paid</th>
                      <th className="text-right p-2 text-red-600">Remaining</th>
                      <th className="text-right p-2">Due Date</th>
                      <th className="text-right p-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {khataEntries.map(e => (
                      <tr key={e.id} className="border-b last:border-0 bg-white">
                        <td className="p-2">{e.description}</td>
                        <td className="text-right p-2">{e.totalAmount}</td>
                        <td className="text-right p-2">{e.paidAmount}</td>
                        <td className="text-right p-2 text-red-600 font-bold">{e.remainingAmount}</td>
                        <td className="text-right p-2">{e.nextPaymentDueDate}</td>
                        <td className="text-right p-2">
                          <button onClick={() => onDeleteKhata(e.id)} className="text-red-600 hover:text-red-800 text-sm">Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="mt-4 text-sm text-slate-600">To add new Khata entries, please go to the 'Khata (Financials)' tab.</p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-6 border-t flex justify-between items-center bg-slate-100">
          <div>
            <button onClick={handleDeleteCase} className="bg-red-500 text-white px-5 py-2 rounded-md hover:bg-red-600 mr-4" disabled={isSaving}>
              Delete Case
            </button>
            <button onClick={onClose} className="bg-slate-200 text-slate-700 px-5 py-2 rounded-md hover:bg-slate-300">
              Close
            </button>
          </div>
          <button onClick={handleSave} className="bg-blue-600 text-white px-8 py-3 rounded-md hover:bg-blue-700" disabled={isSaving}>
            {isSaving ? 'Saving...' : 'Save All Changes'}
          </button>
        </div>
      </div>
    </div>
  );
};

// --- End CaseDetailsModal Component ---

const ALL_SPECIALTIES = [
    "Family Law",
    "Criminal Law",
    "Corporate Law",
    "Tax Law",
    "Civil Litigation",
    "Immigration",
    "Real Estate",
    "Environmental Law",
    "Intellectual Property",
    "Labor Law",
    "Constitutional Law",
    "Banking & Finance"
];

// --- AI Document Schemas (Questionnaires) ---
type FieldType = 'text' | 'number' | 'date' | 'textarea';

interface DocField {
    id: string;
    label: string;
    type: FieldType;
    placeholder?: string;
}

const DOC_TEMPLATES: Record<string, DocField[]> = {
    "Legal Notice": [
        { id: "senderName", label: "Sender's Name (Who is sending?)", type: "text", placeholder: "e.g. Ali Ahmed" },
        { id: "senderAddress", label: "Sender's Address", type: "text", placeholder: "Full Address" },
        { id: "receiverName", label: "Receiver's Name (Who is it for?)", type: "text", placeholder: "e.g. Mr. Khan" },
        { id: "receiverAddress", label: "Receiver's Address", type: "text", placeholder: "Full Address" },
        { id: "grievance", label: "The Issue/Grievance (What happened?)", type: "textarea", placeholder: "e.g. Non-payment of rent for 3 months..." },
        { id: "demand", label: "Your Demand (What do you want?)", type: "textarea", placeholder: "e.g. Pay 50,000 PKR within 7 days..." },
        { id: "deadline", label: "Deadline Date", type: "date" }
    ],
    "Rental Agreement": [
        { id: "landlordName", label: "Landlord Name", type: "text" },
        { id: "landlordCNIC", label: "Landlord CNIC", type: "text" },
        { id: "tenantName", label: "Tenant Name", type: "text" },
        { id: "tenantCNIC", label: "Tenant CNIC", type: "text" },
        { id: "propertyAddress", label: "Property Address", type: "textarea" },
        { id: "rentAmount", label: "Monthly Rent (PKR)", type: "number" },
        { id: "securityDeposit", label: "Security Deposit (PKR)", type: "number" },
        { id: "startDate", label: "Lease Start Date", type: "date" },
        { id: "duration", label: "Duration (Months/Years)", type: "text", placeholder: "e.g. 11 Months" },
        { id: "terms", label: "Special Terms (Optional)", type: "textarea", placeholder: "e.g. No pets allowed..." }
    ],
    "Affidavit": [
        { id: "affiantName", label: "Affiant Name (Person making oath)", type: "text" },
        { id: "affiantFatherName", label: "Father's Name", type: "text" },
        { id: "affiantCNIC", label: "CNIC Number", type: "text" },
        { id: "address", label: "Residential Address", type: "textarea" },
        { id: "statement", label: "Statement of Fact (What are you declaring?)", type: "textarea", placeholder: "e.g. I declare that date of birth is..." },
        { id: "purpose", label: "Purpose of Affidavit", type: "text", placeholder: "e.g. For University Admission" }
    ],
    "Power of Attorney": [
        { id: "principalName", label: "Principal Name (Giver)", type: "text" },
        { id: "agentName", label: "Agent/Attorney Name (Receiver)", type: "text" },
        { id: "relationship", label: "Relationship between Parties", type: "text", placeholder: "e.g. Brother" },
        { id: "propertyDetails", label: "Property/Asset Details (if applicable)", type: "textarea" },
        { id: "powers", label: "Powers Granted (What can they do?)", type: "textarea", placeholder: "e.g. Sell property, sign bank checks..." },
        { id: "revocable", label: "Revocable or Irrevocable?", type: "text", placeholder: "e.g. Irrevocable" }
    ],
    "Divorce Deed": [
        { id: "husbandName", label: "Husband's Name", type: "text" },
        { id: "wifeName", label: "Wife's Name", type: "text" },
        { id: "dateOfMarriage", label: "Date of Marriage", type: "date" },
        { id: "dowerAmount", label: "Haq Mehr Amount", type: "text" },
        { id: "reason", label: "Reason (Optional)", type: "textarea" },
        { id: "custody", label: "Child Custody Details (if any)", type: "textarea" },
        { id: "maintenance", label: "Maintenance/Alimony Settlement", type: "textarea" }
    ],
    "Employment Contract": [
        { id: "employerName", label: "Employer (Company Name)", type: "text" },
        { id: "employeeName", label: "Employee Name", type: "text" },
        { id: "jobTitle", label: "Job Title", type: "text" },
        { id: "salary", label: "Monthly Salary", type: "text" },
        { id: "startDate", label: "Start Date", type: "date" },
        { id: "probation", label: "Probation Period", type: "text", placeholder: "e.g. 3 Months" },
        { id: "duties", label: "Key Duties", type: "textarea" }
    ]
};

export default function LawyerDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'profile' | 'cases' | 'khata' | 'verification' | 'tools' | 'appointments'>('profile');
  const [profile, setProfile] = useState<LawyerProfile | undefined>(undefined);
  const [cases, setCases] = useState<Case[]>([]);
  const [khataEntries, setKhataEntries] = useState<KhataEntry[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);

  // Case Details Modal State
  const [isCaseDetailsModalOpen, setIsCaseDetailsModalOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);

  // Form States
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [tempProfile, setTempProfile] = useState<Partial<LawyerProfile>>({});
  
  // Dropdown Data for Edit Profile
  const [availableCountries, setAvailableCountries] = useState<Country[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);

  // Upload States (only for profile picture & article images now)
  const [uploading, setUploading] = useState<{[key: string]: boolean}>({});

  // AI States
  const [docType, setDocType] = useState('Legal Notice');
  // Replaced docDetails string with a dynamic form object
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [generatedDoc, setGeneratedDoc] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  // New Case State
  const [newCase, setNewCase] = useState<Partial<Case>>({ 
    stage: 'Filing', 
    status: 'Open', 
    importantDates: [], 
    caseFiles: [] 
  });
  
  // Khata State
  const [newKhata, setNewKhata] = useState<Partial<KhataEntry>>({});

  useEffect(() => {
    if (user) {
      loadData();
      getAppLogoUrl().then(setAppLogoUrl);
    }
  }, [user]);

  // Effect to load countries for dropdown
  useEffect(() => {
      const fetchCountries = async () => {
          const countries = await db.getCountries();
          setAvailableCountries(countries);
      };
      fetchCountries();
  }, []);

  // Effect to load cities when tempProfile.country changes
  useEffect(() => {
      const fetchCities = async () => {
          if (tempProfile.country) {
              const cities = await db.getCitiesByCountry(tempProfile.country);
              setAvailableCities(cities);
          } else {
              setAvailableCities([]);
          }
      };
      fetchCities();
  }, [tempProfile.country]);

  // Reset form values when doc type changes
  useEffect(() => {
      setFormValues({});
      setGeneratedDoc('');
  }, [docType]);

  const loadData = async () => {
    if (!user) return;
    const p = await db.getLawyerProfile(user.uid);
    setProfile(p);
    if (p) {
      setTempProfile(p);
      const c = await db.getLawyerCases(user.uid);
      setCases(c);
      
      const b = await getBookingsForLawyer(user.uid);
      setBookings(b);
      
      // Load all Khata entries for these cases
      let allKhata: KhataEntry[] = [];
      const khataPromises = c.map(kase => db.getCaseKhata(kase.id));
      const khataResults = await Promise.all(khataPromises);
      khataResults.forEach(entries => {
          allKhata = [...allKhata, ...entries];
      });
      setKhataEntries(allKhata);
    } else {
      setIsEditingProfile(true); // Force create profile
      setTempProfile({ uid: user.uid, contactEmail: user.email, specialties: [] } as any);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempProfile.fullName) return;
    
    const savedProfile = {
      ...tempProfile,
      uid: user!.uid,
      verificationStatus: tempProfile.verificationStatus || 'none',
      isVerified: tempProfile.isVerified || false,
      contactEmail: user!.email // Ensure email is tied to user
    } as LawyerProfile;

    await db.updateLawyerProfile(savedProfile);
    setProfile(savedProfile);
    setIsEditingProfile(false);
  };
  
  const handleProfilePicUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0] && user) {
          try {
              setUploading(prev => ({ ...prev, profile: true }));
              const originalFile = e.target.files[0];
              const compressedFile = await compressImage(originalFile, 800, 800, 0.7); // Max 800px, 70% quality

              const path = `profile-pictures/${user.uid}/${Date.now()}_${compressedFile.name}`;
              const oldPictureUrl = profile?.picture; // Get old URL for deletion
              const url = await db.uploadFile(compressedFile, path, oldPictureUrl);
              
              setTempProfile(prev => ({ ...prev, picture: url }));
              // Auto save if viewing profile, otherwise just update temp
              if (profile) {
                  const updated = { ...profile, picture: url };
                  await db.updateLawyerProfile(updated);
                  setProfile(updated);
              }
          } catch (error) {
              alert("Failed to upload profile picture");
              console.error(error);
          } finally {
              setUploading(prev => ({ ...prev, profile: false }));
          }
      }
  };


  const handleAddCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCase.caseTitle || !newCase.clientName) return;
    
    const c: Case = {
        id: `case_${Date.now()}`,
        lawyerId: user!.uid,
        clientName: newCase.clientName!,
        caseTitle: newCase.caseTitle!,
        courtName: newCase.courtName || '',
        nextHearingDate: newCase.nextHearingDate || '',
        stage: newCase.stage || 'Filing',
        notes: newCase.notes || '',
        // New fields
        description: newCase.description || '',
        opposingCounsel: newCase.opposingCounsel || '',
        status: newCase.status || 'Open',
        importantDates: [], // Start empty
        caseFiles: [] // Start empty
    };
    await db.addCase(c);
    setCases([...cases, c]);
    setNewCase({ stage: 'Filing', status: 'Open', importantDates: [], caseFiles: [] }); // Reset form
  };

  const handleUpdateCaseInState = (updatedCase: Case) => {
    setCases(cases.map(c => (c.id === updatedCase.id ? updatedCase : c)));
  };

  const handleDeleteCaseInState = (caseId: string) => {
    setCases(cases.filter(c => c.id !== caseId));
    setKhataEntries(prev => prev.filter(k => k.caseId !== caseId)); // Also remove associated khata
  };

  const handleAddKhata = async (e: React.FormEvent) => {
      e.preventDefault();
      if(!newKhata.caseId || !newKhata.totalAmount) return;
      
      const entry: KhataEntry = {
          id: `khata_${Date.now()}`,
          caseId: newKhata.caseId,
          totalAmount: Number(newKhata.totalAmount),
          paidAmount: Number(newKhata.paidAmount || 0),
          remainingAmount: Number(newKhata.totalAmount) - Number(newKhata.paidAmount || 0),
          nextPaymentDueDate: newKhata.nextPaymentDueDate || '',
          description: newKhata.description || 'Legal Fees'
      };
      await db.addKhataEntry(entry);
      setKhataEntries([...khataEntries, entry]);
      setNewKhata({});
      alert("Khata entry added!");
  };

  const handleDeleteKhata = async (entryId: string) => {
    if (window.confirm("Are you sure you want to delete this Khata entry?")) {
        await db.deleteKhataEntry(entryId);
        setKhataEntries(prev => prev.filter(k => k.id !== entryId));
        alert("Khata entry deleted.");
    }
  };
  
  const handleVerificationRequest = async () => {
      if (!profile || !user) return; // Ensure profile and user exist

      // Check if all required textual fields are filled
      if (!tempProfile.degreeName || !tempProfile.issuingAuthority || !tempProfile.licenseNumber ||
          !tempProfile.enrollmentOrRollNumber || !tempProfile.yearOfGraduation || !tempProfile.barCouncilName) {
          alert("Please fill in all required verification details.");
          return;
      }
      
      const req: VerificationRequest = {
          id: `req_${user.uid}_${Date.now()}`, // Unique ID for request
          lawyerId: user.uid,
          lawyerName: profile.fullName,
          lawyerEmail: user.email, // Add lawyer's email to request
          submittedAt: new Date().toISOString(),
          status: 'pending',
          degreeName: tempProfile.degreeName,
          issuingAuthority: tempProfile.issuingAuthority,
          licenseNumber: tempProfile.licenseNumber,
          enrollmentOrRollNumber: tempProfile.enrollmentOrRollNumber,
          yearOfGraduation: tempProfile.yearOfGraduation,
          barCouncilName: tempProfile.barCouncilName,
      };
      await db.submitVerification(req);
      const updatedProfile = { ...profile, verificationStatus: 'pending' as const };
      await db.updateLawyerProfile(updatedProfile); // Update lawyer profile in DB too
      setProfile(updatedProfile);
      alert("Verification application submitted successfully! Admin will review your details.");
  };

  const handleInputChange = (id: string, value: string) => {
      setFormValues(prev => ({
          ...prev,
          [id]: value
      }));
  };

  const handleGenerateDoc = async () => {
      // Validate if form is empty
      const hasData = Object.keys(formValues).length > 0 && Object.values(formValues).some((val: string) => val.trim() !== '');
      if (!hasData) {
          alert("Please fill in the details form before generating the document.");
          return;
      }

      setAiLoading(true);
      
      // Construct a very specific prompt for "Template Filling" behavior
      const lawyerContext = profile ? `Jurisdiction: ${profile.country || 'Pakistan'}, City: ${profile.city || 'Any'}` : 'Jurisdiction: Pakistan';
      
      let promptDetails = `
      ACT AS A SENIOR LEGAL DRAFTER. 
      TASK: Draft a formal ${docType} valid in ${lawyerContext}.
      
      INSTRUCTIONS:
      1. Use STANDARD LEGAL BOILERPLATE language (Standard Tehrir). Do not invent new clauses unless necessary.
      2. The output must be a complete, professional document ready for printing.
      3. FILL IN THE BLANKS of the standard template using the specific details below.
      4. If a detail is missing, use a placeholder like [_____________].
      
      SPECIFIC DETAILS TO INSERT:
      `;
      
      Object.entries(formValues).forEach(([key, value]) => {
          const field = DOC_TEMPLATES[docType]?.find(f => f.id === key);
          const label = field ? field.label : key;
          promptDetails += `- ${label}: ${value}\n`;
      });

      const res = await generateLegalDocument(docType, promptDetails);
      setGeneratedDoc(res);
      setAiLoading(false);
  };
  
  const handleCopyDoc = () => {
      if (generatedDoc) {
          navigator.clipboard.writeText(generatedDoc);
          alert("Document copied to clipboard!");
      }
  };

  const handleDownloadDoc = () => {
      // Simple mock download text file
      if (generatedDoc) {
          const element = document.createElement("a");
          const file = new Blob([generatedDoc], {type: 'text/plain'});
          element.href = URL.createObjectURL(file);
          element.download = `${docType}_Draft.txt`;
          document.body.appendChild(element); // Required for this to work in FireFox
          element.click();
          document.body.removeChild(element);
      }
  };

  const handleSpecialtyToggle = (specialty: string) => {
      setTempProfile(prev => {
          const current = prev.specialties || [];
          if (current.includes(specialty)) {
              return { ...prev, specialties: current.filter(s => s !== specialty) };
          } else {
              return { ...prev, specialties: [...current, specialty] };
          }
      });
  };
  
  const handleBookingAction = async (bookingId: string, action: 'confirmed' | 'rejected') => {
      try {
          await updateBookingStatus(bookingId, action);
          setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: action } : b));
          alert(`Booking marked as ${action}.`);
      } catch (error) {
          console.error("Error updating booking:", error);
          alert("Failed to update booking status.");
      }
  };

  if (!user) return null;

  const isSubmitVerificationDisabled = 
      !tempProfile.degreeName || 
      !tempProfile.issuingAuthority || 
      !tempProfile.licenseNumber ||
      !tempProfile.enrollmentOrRollNumber || 
      !tempProfile.yearOfGraduation || 
      !tempProfile.barCouncilName ||
      profile?.verificationStatus === 'pending'; // Disable if already pending

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Admin Switcher */}
      {user.role === 'admin' && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-lg mb-8 flex justify-between items-center">
            <div>
                <h3 className="font-bold text-red-800">Administrator Access</h3>
                <p className="text-sm text-red-600">You are viewing this page as a Lawyer. Switch to the Admin Portal to manage the platform.</p>
            </div>
            <button 
                onClick={() => navigate('/dashboard/admin')}
                className="bg-red-600 text-white px-4 py-2 rounded font-semibold hover:bg-red-700 shadow"
            >
                Go to Admin Portal
            </button>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Navigation */}
        <aside className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex flex-col items-center mb-6">
               <div className="relative group cursor-pointer w-24 h-24 mb-3">
                   <div className="w-24 h-24 rounded-full bg-slate-200 overflow-hidden border-2 border-slate-100 shadow flex items-center justify-center">
                       <img 
                            src={profile?.picture || appLogoUrl || DEFAULT_LOGO_SVG} 
                            alt="Profile" 
                            className="w-full h-full object-cover"
                            onError={(e) => { 
                                const img = e.currentTarget;
                                img.onerror = null; // STOP INFINITE LOOP
                                img.src = DEFAULT_LOGO_SVG; 
                            }}
                       />
                   </div>
                   <label className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 rounded-full flex items-center justify-center transition cursor-pointer">
                        <input type="file" className="hidden" accept="image/*" onChange={handleProfilePicUpload} />
                        <svg className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                   </label>
                   {uploading.profile && <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full"><div className="animate-spin h-6 w-6 border-2 border-white rounded-full border-t-transparent"></div></div>}
               </div>
               {/* New instructional text */}
               <p className="text-xs text-slate-500 mt-1 mb-2">Click image to change profile picture</p>
               
               <h3 className="font-bold text-lg text-center">{profile?.fullName || 'New Lawyer'}</h3>
               {profile?.isVerified && (
                   <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full mt-1 flex items-center">
                       <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/></svg>
                       Verified
                   </span>
               )}
               {(profile?.verificationStatus as string) === 'pending' && !profile.isVerified && (
                   <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full mt-1 flex items-center">
                       <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                       Pending
                   </span>
               )}
               {profile?.verificationStatus === 'rejected' && !profile.isVerified && (
                   <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full mt-1 flex items-center">
                       <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                       Rejected
                   </span>
               )}
            </div>
            <nav className="space-y-2">
              <button onClick={() => setActiveTab('profile')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'profile' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>My Profile</button>
              <button onClick={() => setActiveTab('appointments')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'appointments' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>Appointments</button>
              <button onClick={() => setActiveTab('cases')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'cases' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>Case Manager</button>
              <button onClick={() => setActiveTab('khata')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'khata' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>Khata (Financials)</button>
              <button onClick={() => setActiveTab('verification')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'verification' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>Verification</button>
              <button onClick={() => setActiveTab('tools')} className={`w-full text-left px-4 py-2 rounded ${activeTab === 'tools' ? 'bg-blue-50 text-blue-600' : 'hover:bg-slate-50'}`}>AI Tools</button>
            </nav>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-grow bg-white rounded-lg shadow p-8">
          
          {/* PROFILE TAB */}
          {activeTab === 'profile' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">My Profile</h2>
                {!isEditingProfile && <button onClick={() => setIsEditingProfile(true)} className="text-blue-600 hover:underline">Edit Profile</button>}
              </div>

              {isEditingProfile ? (
                <form onSubmit={handleSaveProfile} className="space-y-6">
                  {/* Basic Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div><label className="block text-sm font-medium mb-1">Full Name</label><input required className="w-full border p-2 rounded" value={tempProfile.fullName || ''} onChange={e => setTempProfile({...tempProfile, fullName: e.target.value})} /></div>
                      <div><label className="block text-sm font-medium mb-1">Title (Advocate/Barrister)</label><input className="w-full border p-2 rounded" value={tempProfile.title || ''} onChange={e => setTempProfile({...tempProfile, title: e.target.value})} /></div>
                  </div>

                  {/* Location & Specialty */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="md:col-span-1">
                          <label className="block text-sm font-medium mb-2">Specialties</label>
                          <div className="border rounded p-3 h-48 overflow-y-auto bg-slate-50">
                              {ALL_SPECIALTIES.map(s => (
                                  <label key={s} className="flex items-center space-x-2 mb-2 cursor-pointer">
                                      <input 
                                          type="checkbox" 
                                          checked={tempProfile.specialties?.includes(s) || false}
                                          onChange={() => handleSpecialtyToggle(s)}
                                          className="rounded text-blue-600 focus:ring-blue-500"
                                      />
                                      <span className="text-sm text-slate-700">{s}</span>
                                  </label>
                              ))}
                          </div>
                          <p className="text-xs text-slate-500 mt-1">Select all that apply.</p>
                      </div>
                      
                      <div className="md:col-span-2 space-y-4">
                        <div><label className="block text-sm font-medium mb-1">Country</label>
                             <select className="w-full border p-2 rounded" value={tempProfile.country || ''} onChange={e => setTempProfile({...tempProfile, country: e.target.value, city: ''})}>
                                 <option value="">Select Country</option>
                                 {availableCountries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                             </select>
                          </div>
                          <div><label className="block text-sm font-medium mb-1">City</label>
                            <select className="w-full border p-2 rounded" value={tempProfile.city || ''} onChange={e => setTempProfile({...tempProfile, city: e.target.value})} disabled={!tempProfile.country}>
                                 <option value="">Select City</option>
                                 {availableCities.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                          </div>
                      </div>
                  </div>

                  {/* Office Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div><label className="block text-sm font-medium mb-1">Office Name (e.g. Decent Law Firm)</label><input className="w-full border p-2 rounded" value={tempProfile.officeName || ''} onChange={e => setTempProfile({...tempProfile, officeName: e.target.value})} /></div>
                      <div><label className="block text-sm font-medium mb-1">Office Address</label><input className="w-full border p-2 rounded" value={tempProfile.officeAddress || ''} onChange={e => setTempProfile({...tempProfile, officeAddress: e.target.value})} /></div>
                  </div>

                  {/* Contact Info */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div><label className="block text-sm font-medium mb-1">Mobile</label><input className="w-full border p-2 rounded" value={tempProfile.contactMobile || ''} onChange={e => setTempProfile({...tempProfile, contactMobile: e.target.value})} /></div>
                      <div><label className="block text-sm font-medium mb-1">WhatsApp</label><input className="w-full border p-2 rounded" value={tempProfile.contactWhatsapp || ''} onChange={e => setTempProfile({...tempProfile, contactWhatsapp: e.target.value})} /></div>
                      <div><label className="block text-sm font-medium mb-1">Email</label><input type="email" disabled className="w-full border p-2 rounded bg-slate-100 text-slate-500" value={user.email || ''} /></div>
                  </div>

                  {/* About */}
                  <div>
                      <label className="block text-sm font-medium mb-1">About Me</label>
                      <textarea className="w-full border p-2 rounded" rows={3} value={tempProfile.aboutMe || ''} onChange={e => setTempProfile({...tempProfile, aboutMe: e.target.value})} />
                  </div>

                  {/* Achievements */}
                  <div>
                      <label className="block text-sm font-medium mb-1">Achievements / Notable Cases</label>
                      <textarea className="w-full border p-2 rounded" rows={2} value={tempProfile.achievements || ''} onChange={e => setTempProfile({...tempProfile, achievements: e.target.value})} />
                  </div>

                  <div className="flex gap-4">
                      <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Save Profile</button>
                      <button type="button" onClick={() => {setIsEditingProfile(false); setTempProfile(profile!);}} className="bg-slate-200 text-slate-700 px-6 py-2 rounded hover:bg-slate-300">Cancel</button>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4 text-sm">
                        <p><span className="font-bold">Name:</span> {profile?.fullName}</p>
                        <p><span className="font-bold">Title:</span> {profile?.title}</p>
                        <p><span className="font-bold">Specialties:</span> {profile?.specialties?.join(', ') || 'General'}</p>
                        <p><span className="font-bold">Location:</span> {profile?.city}, {profile?.country}</p>
                        <p><span className="font-bold">Office:</span> {profile?.officeName}</p>
                        <p><span className="font-bold">Address:</span> {profile?.officeAddress}</p>
                        <p><span className="font-bold">Mobile:</span> {profile?.contactMobile}</p>
                        <p><span className="font-bold">WhatsApp:</span> {profile?.contactWhatsapp}</p>
                        <p><span className="font-bold">Email:</span> {profile?.contactEmail}</p>
                    </div>
                    <div>
                        <h3 className="font-bold mb-1">About Me</h3>
                        <p className="text-slate-700">{profile?.aboutMe || 'No details added.'}</p>
                    </div>
                    <div>
                        <h3 className="font-bold mb-1">Achievements</h3>
                        <p className="text-slate-700">{profile?.achievements || 'No details added.'}</p>
                    </div>
                </div>
              )}
            </div>
          )}

          {/* APPOINTMENTS TAB */}
          {activeTab === 'appointments' && (
              <div>
                  <h2 className="text-2xl font-bold mb-6">Appointments</h2>
                  {bookings.length === 0 ? (
                      <p className="text-slate-500 italic">No appointment requests yet.</p>
                  ) : (
                      <div className="overflow-x-auto">
                          <table className="min-w-full text-left text-sm">
                              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold">
                                  <tr>
                                      <th className="p-3">Client</th>
                                      <th className="p-3">Date</th>
                                      <th className="p-3">Time</th>
                                      <th className="p-3">Reason</th>
                                      <th className="p-3">Status</th>
                                      <th className="p-3">Actions</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  {bookings.map(book => (
                                      <tr key={book.id} className="border-b last:border-0 hover:bg-slate-50">
                                          <td className="p-3">
                                              <p className="font-bold">{book.clientName}</p>
                                              <p className="text-xs text-slate-400">{book.clientEmail}</p>
                                          </td>
                                          <td className="p-3">{book.date}</td>
                                          <td className="p-3">{book.time}</td>
                                          <td className="p-3 max-w-xs truncate" title={book.notes}>{book.notes}</td>
                                          <td className="p-3">
                                              <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
                                                  book.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                                                  book.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                                  'bg-yellow-100 text-yellow-700'
                                              }`}>
                                                  {book.status}
                                              </span>
                                          </td>
                                          <td className="p-3">
                                              {book.status === 'pending' && (
                                                  <div className="flex gap-2">
                                                      <button 
                                                          onClick={() => handleBookingAction(book.id, 'confirmed')}
                                                          className="text-green-600 hover:text-green-800 font-bold text-xs border border-green-600 px-2 py-1 rounded"
                                                      >
                                                          Confirm
                                                      </button>
                                                      <button 
                                                          onClick={() => handleBookingAction(book.id, 'rejected')}
                                                          className="text-red-600 hover:text-red-800 font-bold text-xs border border-red-600 px-2 py-1 rounded"
                                                      >
                                                          Reject
                                                      </button>
                                                  </div>
                                              )}
                                              {book.status !== 'pending' && <span className="text-slate-400 text-xs">No actions</span>}
                                          </td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                  )}
              </div>
          )}

          {/* CASES TAB */}
          {activeTab === 'cases' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Case Manager</h2>
              </div>
              
              {/* Add Case Form */}
              <div className="bg-slate-50 p-6 rounded-lg mb-8 border border-slate-200">
                <h3 className="font-bold text-lg mb-4">Add New Case</h3>
                <form onSubmit={handleAddCase} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input required placeholder="Case Title (e.g. State vs Ali)" className="border p-2 rounded" value={newCase.caseTitle || ''} onChange={e => setNewCase({...newCase, caseTitle: e.target.value})} />
                    <input required placeholder="Client Name" className="border p-2 rounded" value={newCase.clientName || ''} onChange={e => setNewCase({...newCase, clientName: e.target.value})} />
                    <input placeholder="Court Name" className="border p-2 rounded" value={newCase.courtName || ''} onChange={e => setNewCase({...newCase, courtName: e.target.value})} />
                    <input placeholder="Opposing Party / Counsel" className="border p-2 rounded" value={newCase.opposingCounsel || ''} onChange={e => setNewCase({...newCase, opposingCounsel: e.target.value})} />
                    <input type="date" placeholder="Next Hearing Date" className="border p-2 rounded" value={newCase.nextHearingDate || ''} onChange={e => setNewCase({...newCase, nextHearingDate: e.target.value})} />
                    <select className="border p-2 rounded" value={newCase.stage || 'Filing'} onChange={e => setNewCase({...newCase, stage: e.target.value})}>
                        <option value="Filing">Filing</option>
                        <option value="Hearing">Hearing</option>
                        <option value="Evidence">Evidence</option>
                        <option value="Verdict">Verdict</option>
                        <option value="Appeal">Appeal</option>
                        <option value="Closed">Closed</option>
                    </select>
                    <textarea placeholder="Short Description / Case Summary" className="border p-2 rounded md:col-span-2" rows={2} value={newCase.description || ''} onChange={e => setNewCase({...newCase, description: e.target.value})} />
                    <textarea placeholder="Initial Notes" className="border p-2 rounded md:col-span-2" rows={1} value={newCase.notes || ''} onChange={e => setNewCase({...newCase, notes: e.target.value})} />
                    <button type="submit" className="bg-green-600 text-white px-6 py-2 rounded md:col-span-2 hover:bg-green-700">Add Case</button>
                </form>
              </div>

              {/* Cases List */}
              <div className="space-y-4">
                  {cases.length === 0 ? (
                      <p className="text-slate-500 italic">No cases added yet.</p>
                  ) : (
                      cases.map(c => (
                          <div key={c.id} className="border p-4 rounded-lg hover:shadow-md transition bg-white">
                              <div className="flex justify-between items-start">
                                  <div>
                                      <h3 className="font-bold text-lg text-slate-800">{c.caseTitle}</h3>
                                      <p className="text-sm text-slate-500">Client: {c.clientName} | Court: {c.courtName}</p>
                                      {c.description && <p className="text-sm text-slate-600 mt-1 italic line-clamp-1">{c.description}</p>}
                                  </div>
                                  <div className="text-right">
                                      <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${c.status === 'Closed' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                                          {c.stage}
                                      </span>
                                      <p className="text-xs text-slate-400 mt-1">Next: {c.nextHearingDate || 'TBD'}</p>
                                  </div>
                              </div>
                              <div className="mt-4 pt-3 border-t flex justify-between items-center">
                                  <span className="text-xs text-slate-400">{c.caseFiles?.length || 0} Files &bull; {c.importantDates?.length || 0} Dates</span>
                                  <button 
                                    onClick={() => { setSelectedCase(c); setIsCaseDetailsModalOpen(true); }} 
                                    className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                                  >
                                      View / Edit Details →
                                  </button>
                              </div>
                          </div>
                      ))
                  )}
              </div>
            </div>
          )}

          {/* KHATA TAB */}
          {activeTab === 'khata' && (
             <div>
                 <h2 className="text-2xl font-bold mb-6">Financial Ledger (Khata)</h2>
                 
                 {/* Add Khata Entry */}
                 <div className="bg-slate-50 p-6 rounded-lg mb-8 border border-slate-200">
                     <h3 className="font-bold text-lg mb-4">Add Payment Record</h3>
                     <form onSubmit={handleAddKhata} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <select required className="border p-2 rounded md:col-span-2" value={newKhata.caseId || ''} onChange={e => setNewKhata({...newKhata, caseId: e.target.value})}>
                             <option value="">Select Case</option>
                             {cases.map(c => <option key={c.id} value={c.id}>{c.caseTitle} - {c.clientName}</option>)}
                         </select>
                         <input type="number" required placeholder="Total Agreed Amount" className="border p-2 rounded" value={newKhata.totalAmount || ''} onChange={e => setNewKhata({...newKhata, totalAmount: Number(e.target.value)})} />
                         <input type="number" placeholder="Paid Amount (Advance)" className="border p-2 rounded" value={newKhata.paidAmount || ''} onChange={e => setNewKhata({...newKhata, paidAmount: Number(e.target.value)})} />
                         <input type="date" placeholder="Next Payment Due Date" className="border p-2 rounded" value={newKhata.nextPaymentDueDate || ''} onChange={e => setNewKhata({...newKhata, nextPaymentDueDate: e.target.value})} />
                         <input type="text" placeholder="Description / Payment Note" className="border p-2 rounded" value={newKhata.description || ''} onChange={e => setNewKhata({...newKhata, description: e.target.value})} />
                         <button type="submit" className="bg-amber-500 text-blue-900 font-bold px-6 py-2 rounded md:col-span-2 hover:bg-amber-400">Add Entry</button>
                     </form>
                 </div>

                 {/* Khata List */}
                 <div className="overflow-x-auto">
                     <table className="w-full text-left border-collapse">
                         <thead className="bg-slate-100 text-slate-600 uppercase text-xs">
                             <tr>
                                 <th className="p-3 border-b">Client / Case</th>
                                 <th className="p-3 border-b">Description</th>
                                 <th className="p-3 border-b text-right">Total</th>
                                 <th className="p-3 border-b text-right">Paid</th>
                                 <th className="p-3 border-b text-right">Remaining</th>
                                 <th className="p-3 border-b">Due Date</th>
                                 <th className="p-3 border-b">Action</th>
                             </tr>
                         </thead>
                         <tbody>
                             {khataEntries.length === 0 ? (
                                 <tr><td colSpan={7} className="p-4 text-center text-slate-500">No records found.</td></tr>
                             ) : (
                                 khataEntries.map(entry => {
                                     const relatedCase = cases.find(c => c.id === entry.caseId);
                                     return (
                                         <tr key={entry.id} className="hover:bg-slate-50">
                                             <td className="p-3 border-b">
                                                 <div className="font-bold text-slate-800">{relatedCase?.clientName || 'Unknown'}</div>
                                                 <div className="text-xs text-slate-500">{relatedCase?.caseTitle}</div>
                                             </td>
                                             <td className="p-3 border-b text-sm">{entry.description}</td>
                                             <td className="p-3 border-b text-right font-mono">{entry.totalAmount}</td>
                                             <td className="p-3 border-b text-right font-mono text-green-600">{entry.paidAmount}</td>
                                             <td className="p-3 border-b text-right font-mono text-red-600 font-bold">{entry.remainingAmount}</td>
                                             <td className="p-3 border-b text-sm">{entry.nextPaymentDueDate}</td>
                                             <td className="p-3 border-b">
                                                 <button onClick={() => handleDeleteKhata(entry.id)} className="text-red-500 hover:text-red-700 text-xs uppercase font-bold">Delete</button>
                                             </td>
                                         </tr>
                                     )
                                 })
                             )}
                         </tbody>
                     </table>
                 </div>
             </div>
          )}
          
          {/* VERIFICATION TAB */}
          {activeTab === 'verification' && (
              <div className="max-w-3xl">
                  <h2 className="text-2xl font-bold mb-6">License Verification</h2>
                  
                  {profile?.isVerified ? (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                          <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                          <h3 className="text-xl font-bold text-green-800 mb-2">You are Verified!</h3>
                          <p className="text-green-700">Your profile now displays a verification badge, increasing client trust.</p>
                      </div>
                  ) : profile?.verificationStatus === 'pending' ? (
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
                          <svg className="w-16 h-16 text-yellow-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                          <h3 className="text-xl font-bold text-yellow-800 mb-2">Verification Pending</h3>
                          <p className="text-yellow-700">Your application is under review by the admin team.</p>
                      </div>
                  ) : (
                      <div>
                          {profile?.verificationStatus === 'rejected' && (
                              <div className="bg-red-50 border border-red-200 p-4 rounded mb-6 text-red-700">
                                  <strong>Application Rejected:</strong> {profile.rejectionReason || 'Details not valid.'} <br/>Please correct your profile details and submit again.
                              </div>
                          )}
                          <div className="bg-white border border-slate-200 p-6 rounded-lg shadow-sm">
                              <p className="mb-6 text-slate-600">To get the <strong>Verified Badge</strong>, please ensure your profile is fully updated with the following details. The admin will verify this information manually.</p>
                              
                              <div className="space-y-4 mb-8">
                                  <div>
                                      <label className="block text-sm font-medium mb-1">Law Degree Name (LL.B / LL.M / Bar-at-Law)</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.degreeName || ''} onChange={e => setTempProfile({...tempProfile, degreeName: e.target.value})} placeholder="e.g. LL.B (Hons)" />
                                  </div>
                                  <div>
                                      <label className="block text-sm font-medium mb-1">University / Issuing Authority</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.issuingAuthority || ''} onChange={e => setTempProfile({...tempProfile, issuingAuthority: e.target.value})} placeholder="e.g. University of Punjab" />
                                  </div>
                                  <div>
                                      <label className="block text-sm font-medium mb-1">Bar Council License Number</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.licenseNumber || ''} onChange={e => setTempProfile({...tempProfile, licenseNumber: e.target.value})} placeholder="e.g. 12345/LHR" />
                                  </div>
                                  
                                  {/* New Textual Verification Fields */}
                                  <div>
                                      <label className="block text-sm font-medium mb-1">Enrollment / Roll Number</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.enrollmentOrRollNumber || ''} onChange={e => setTempProfile({...tempProfile, enrollmentOrRollNumber: e.target.value})} placeholder="e.g. BC-12345" />
                                  </div>
                                  <div>
                                      <label className="block text-sm font-medium mb-1">Year of Graduation / Enrollment</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.yearOfGraduation || ''} onChange={e => setTempProfile({...tempProfile, yearOfGraduation: e.target.value})} placeholder="e.g. 2015" />
                                  </div>
                                  <div>
                                      <label className="block text-sm font-medium mb-1">Bar Council Name (e.g. Punjab Bar Council)</label>
                                      <input className="w-full border p-2 rounded" value={tempProfile.barCouncilName || ''} onChange={e => setTempProfile({...tempProfile, barCouncilName: e.target.value})} placeholder="e.g. Punjab Bar Council" />
                                  </div>
                              </div>

                              <button 
                                onClick={handleVerificationRequest} 
                                disabled={isSubmitVerificationDisabled}
                                className={`w-full py-3 rounded font-bold transition ${isSubmitVerificationDisabled ? 'bg-slate-300 text-slate-500 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700'}`}
                              >
                                  Submit Verification Request
                              </button>
                          </div>
                      </div>
                  )}
              </div>
          )}

          {/* AI TOOLS TAB */}
          {activeTab === 'tools' && (
              <div className="max-w-4xl">
                  <h2 className="text-2xl font-bold mb-6">AI Legal Assistant</h2>
                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-100 mb-8">
                      <p className="text-purple-900 mb-4">
                          <strong>Standard Legal Drafting:</strong> Select a document type and fill in the specifics. 
                          The AI uses standard legal boilerplate text (Tehrir) suitable for <strong>{profile?.country || 'your jurisdiction'}</strong> and inserts your client's details automatically.
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                          <div>
                              <label className="block text-sm font-bold text-purple-900 mb-2">Document Type</label>
                              <select 
                                  className="w-full border p-3 rounded shadow-sm focus:ring-2 focus:ring-purple-500 outline-none" 
                                  value={docType} 
                                  onChange={e => setDocType(e.target.value)}
                              >
                                  {Object.keys(DOC_TEMPLATES).map(key => (
                                      <option key={key} value={key}>{key}</option>
                                  ))}
                              </select>
                          </div>
                      </div>

                      {/* Dynamic Form Generation based on DocType */}
                      <div className="bg-white p-5 rounded border border-purple-100 shadow-sm mb-6">
                          <h3 className="font-bold text-lg mb-4 text-purple-800 border-b pb-2">Client Details for {docType}</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {DOC_TEMPLATES[docType]?.map((field) => (
                                  <div key={field.id} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{field.label}</label>
                                      {field.type === 'textarea' ? (
                                          <textarea
                                              className="w-full border p-2 rounded focus:ring-2 focus:ring-purple-500 outline-none text-sm"
                                              rows={3}
                                              placeholder={field.placeholder || ''}
                                              value={formValues[field.id] || ''}
                                              onChange={(e) => handleInputChange(field.id, e.target.value)}
                                          />
                                      ) : (
                                          <input
                                              type={field.type}
                                              className="w-full border p-2 rounded focus:ring-2 focus:ring-purple-500 outline-none text-sm"
                                              placeholder={field.placeholder || ''}
                                              value={formValues[field.id] || ''}
                                              onChange={(e) => handleInputChange(field.id, e.target.value)}
                                          />
                                      )}
                                  </div>
                              ))}
                          </div>
                      </div>

                      <button 
                          onClick={handleGenerateDoc} 
                          disabled={aiLoading}
                          className="w-full bg-purple-600 text-white font-bold py-3 rounded shadow hover:bg-purple-700 transition disabled:opacity-70 flex justify-center items-center"
                      >
                          {aiLoading ? (
                              <>
                                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                  </svg>
                                  Drafting Document...
                              </>
                          ) : 'Generate Draft'}
                      </button>
                  </div>

                  {generatedDoc && (
                      <div className="bg-white border p-6 rounded shadow-lg animate-in fade-in slide-in-from-bottom-4 duration-500">
                          <div className="flex justify-between items-center mb-4 border-b pb-4">
                              <h3 className="font-bold text-lg">Final Draft</h3>
                              <div className="space-x-2">
                                  <button onClick={handleCopyDoc} className="text-sm bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded text-slate-700 border border-slate-300">Copy Text</button>
                                  <button onClick={handleDownloadDoc} className="text-sm bg-blue-100 hover:bg-blue-200 px-3 py-1 rounded text-blue-700 border border-blue-300">Download .txt</button>
                              </div>
                          </div>
                          <pre className="whitespace-pre-wrap font-serif text-slate-800 text-sm leading-relaxed bg-slate-50 p-4 rounded border border-slate-100 max-h-[500px] overflow-y-auto">
                              {generatedDoc}
                          </pre>
                      </div>
                  )}
              </div>
          )}

        </main>
      </div>
      
      {/* Integrated Case Details Modal */}
      {selectedCase && (
        <CaseDetailsModal 
          isOpen={isCaseDetailsModalOpen}
          onClose={() => setIsCaseDetailsModalOpen(false)}
          caseData={selectedCase}
          onUpdateCase={handleUpdateCaseInState}
          onDeleteCase={handleDeleteCaseInState}
          lawyerId={user.uid}
          khataEntries={khataEntries.filter(k => k.caseId === selectedCase.id)}
          onDeleteKhata={handleDeleteKhata}
        />
      )}
    </div>
  );
}