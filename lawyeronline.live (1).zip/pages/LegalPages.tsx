import React, { useEffect } from 'react';

// Fix: Make children optional in type definition to prevent TS error about missing children prop
export const LegalLayout = ({ title, children }: { title: string, children?: React.ReactNode }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8 font-serif border-b pb-4">{title}</h1>
        <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed">
          {children}
        </div>
      </div>
    </div>
  );
};

export const PrivacyPolicy = () => {
  return (
    <LegalLayout title="Privacy Policy">
      <p className="mb-4">Last Updated: {new Date().getFullYear()}</p>
      
      <h3 className="text-xl font-bold mt-6 mb-3">1. Introduction</h3>
      <p>Welcome to LawyerOnline. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you as to how we look after your personal data when you visit our website (regardless of where you visit it from) and tell you about your privacy rights and how the law protects you.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">2. Information We Collect</h3>
      <p>We may collect, use, store and transfer different kinds of personal data about you which we have grouped together follows:</p>
      <ul className="list-disc ml-6 mb-4 space-y-2">
        <li><strong>Identity Data:</strong> includes first name, last name, username or similar identifier, title.</li>
        <li><strong>Contact Data:</strong> includes email address, telephone numbers, and physical address (for lawyers).</li>
        <li><strong>Professional Data:</strong> includes bar license numbers, education history, and office details (for verification purposes).</li>
        <li><strong>Technical Data:</strong> includes internet protocol (IP) address, your login data, browser type and version, time zone setting and location, and other technology on the devices you use to access this website.</li>
      </ul>

      <h3 className="text-xl font-bold mt-6 mb-3">3. How We Use Your Data</h3>
      <p>We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:</p>
      <ul className="list-disc ml-6 mb-4 space-y-2">
        <li>To register you as a new customer or lawyer.</li>
        <li>To manage our relationship with you.</li>
        <li>To enable you to partake in a prize draw, competition or complete a survey.</li>
        <li>To administer and protect our business and this website (including troubleshooting, data analysis, testing, system maintenance, support, reporting and hosting of data).</li>
      </ul>

      <h3 className="text-xl font-bold mt-6 mb-3">4. Cookies and AdSense</h3>
      <p>We use cookies to distinguish you from other users of our website. This helps us to provide you with a good experience when you browse our website and also allows us to improve our site.</p>
      <p><strong>Google AdSense:</strong> We use Google AdSense to display advertisements. Google uses cookies to serve ads based on a user's prior visits to our website or other websites. Google's use of advertising cookies enables it and its partners to serve ads to our users based on their visit to our sites and/or other sites on the Internet. Users may opt out of personalized advertising by visiting Ads Settings.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">5. Data Security</h3>
      <p>We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way, altered or disclosed.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">6. Contact Us</h3>
      <p>If you have any questions about this privacy policy or our privacy practices, please contact us at support@lawyeronline.live.</p>
    </LegalLayout>
  );
};

export const TermsOfService = () => {
  return (
    <LegalLayout title="Terms of Service">
      <p className="mb-4">Last Updated: {new Date().getFullYear()}</p>

      <h3 className="text-xl font-bold mt-6 mb-3">1. Acceptance of Terms</h3>
      <p>By accessing and using LawyerOnline, you accept and agree to be bound by the terms and provision of this agreement. In addition, when using these particular services, you shall be subject to any posted guidelines or rules applicable to such services.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">2. Role of LawyerOnline</h3>
      <p>LawyerOnline is a directory and platform connecting clients with legal professionals. We are <strong>not</strong> a law firm and do not provide legal advice. We do not endorse any specific lawyer and are not responsible for the advice or services provided by lawyers listed on our platform.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">3. User Conduct</h3>
      <p>You agree to use the site only for lawful purposes. Lawyers agree to provide accurate, up-to-date information regarding their qualifications and licensing. Any misrepresentation may result in immediate account suspension.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">4. Intellectual Property</h3>
      <p>The Site and its original content, features, and functionality are owned by LawyerOnline and are protected by international copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">5. Termination</h3>
      <p>We may terminate your access to the Site, without cause or notice, which may result in the forfeiture and destruction of all information associated with you.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">6. Limitation of Liability</h3>
      <p>In no event shall LawyerOnline, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.</p>
    </LegalLayout>
  );
};

export const Disclaimer = () => {
  return (
    <LegalLayout title="Disclaimer">
      <p className="mb-4">Last Updated: {new Date().getFullYear()}</p>

      <h3 className="text-xl font-bold mt-6 mb-3">1. No Legal Advice</h3>
      <p>The information provided on LawyerOnline is for general informational purposes only. All information on the Site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability or completeness of any information on the Site.</p>
      <p className="mt-2"><strong>Under no circumstance shall we have any liability to you for any loss or damage of any kind incurred as a result of the use of the site or reliance on any information provided on the site. Your use of the site and your reliance on any information on the site is solely at your own risk.</strong></p>

      <h3 className="text-xl font-bold mt-6 mb-3">2. No Attorney-Client Relationship</h3>
      <p>Use of LawyerOnline does not create an attorney-client relationship between you and LawyerOnline, or between you and any lawyer listed on the site, until you have explicitly entered into a representation agreement with that lawyer. Information exchanged via this platform may not be privileged.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">3. External Links Disclaimer</h3>
      <p>The Site may contain (or you may be sent through the Site) links to other websites or content belonging to or originating from third parties. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability or completeness by us.</p>

      <h3 className="text-xl font-bold mt-6 mb-3">4. Professional Disclaimer</h3>
      <p>The Site cannot and does not contain legal advice. The legal information is provided for general informational and educational purposes only and is not a substitute for professional advice. Accordingly, before taking any actions based upon such information, we encourage you to consult with the appropriate professionals.</p>
    </LegalLayout>
  );
};