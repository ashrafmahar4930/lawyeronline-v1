import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { getArticles, getCountries, getCitiesByCountry, getAllLawyers, getAppLogoUrl, DEFAULT_LOGO_SVG } from '../services/mockDataService';
import { Article, LawyerProfile, Country } from '../types';
import { updateMeta, defaultSchema } from '../utils/seo';

export default function Home() {
  const navigate = useNavigate();
  const [specialty, setSpecialty] = useState('');
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');
  const [articles, setArticles] = useState<Article[]>([]);
  const [loadingArticles, setLoadingArticles] = useState(true); // Added loading state
  const [lawyers, setLawyers] = useState<LawyerProfile[]>([]);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);
  
  // Dropdown Data
  const [availableCountries, setAvailableCountries] = useState<Country[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);

  useEffect(() => {
    // 1. Dynamic SEO for Home
    updateMeta({
      title: "Home",
      description: "LawyerOnline.LIVE is the global platform to find verified lawyers, manage cases with AI, and get legal advice online. Connect with experts in Pakistan, USA, UK & worldwide.",
      image: "https://images.unsplash.com/photo-1505664194779-8beaceb93744?q=80&w=2070&auto=format&fit=crop",
      url: "https://www.lawyeronline.live",
      schema: defaultSchema
    });

    const loadInitData = async () => {
        try {
            setLoadingArticles(true);
            // Fetch Articles
            const fetchedArticles = await getArticles();
            setArticles(fetchedArticles);
            setLoadingArticles(false);
            
            // Fetch Lawyers for Marquee
            const fetchedLawyers = await getAllLawyers();
            
            // Shuffle lawyers for random display
            const shuffledLawyers = fetchedLawyers.sort(() => Math.random() - 0.5);
            setLawyers(shuffledLawyers);

            // Fetch Countries
            const countries = await getCountries();
            setAvailableCountries(countries);

            // Fetch Logo for fallback
            const logo = await getAppLogoUrl();
            setAppLogoUrl(logo);

        } catch (error) {
            console.error("Error loading home data:", error);
            setLoadingArticles(false);
        }
    };
    loadInitData();
  }, []);

  // Update cities when country changes
  useEffect(() => {
      const loadCities = async () => {
          if (country) {
              const cities = await getCitiesByCountry(country);
              setAvailableCities(cities);
              setCity(''); // Reset city selection
          } else {
              setAvailableCities([]);
              setCity('');
          }
      };
      loadCities();
  }, [country]);

  const handleSearch = () => {
    navigate(`/find-lawyers?specialty=${specialty}&country=${country}&city=${city}`);
  };

  // Helper to get flag code (mock implementation)
  const getFlagUrl = (countryName?: string) => {
      const map: Record<string, string> = {
          'Pakistan': 'pk', 'United States': 'us', 'USA': 'us', 'United Kingdom': 'gb', 'UK': 'gb',
          'Canada': 'ca', 'Australia': 'au', 'India': 'in', 'UAE': 'ae', 'United Arab Emirates': 'ae',
          'Saudi Arabia': 'sa', 'Qatar': 'qa', 'Germany': 'de', 'France': 'fr', 'Italy': 'it',
          'Spain': 'es', 'China': 'cn', 'Japan': 'jp', 'Turkey': 'tr', 'Malaysia': 'my',
          'Indonesia': 'id', 'Brazil': 'br', 'Russia': 'ru', 'South Africa': 'za', 'Egypt': 'eg',
          'Nigeria': 'ng', 'Bangladesh': 'bd', 'Mexico': 'mx', 'Philippines': 'ph', 'Vietnam': 'vn',
          'Thailand': 'th'
      };
      const code = map[countryName || ''] || 'pk'; 
      return `https://flagcdn.com/w320/${code}.png`;
  };

  // Helper component for Waving Text (Duplicated from Navbar for self-containment in Home)
  const WavyText = ({ text, className, delayStart = 0, colorClass = "text-white" }: { text: string, className: string, delayStart?: number, colorClass?: string }) => (
    <div className={`flex ${className}`}>
      {text.split('').map((char, i) => (
        <span
          key={i}
          className={`animate-wave inline-block ${colorClass}`}
          style={{ animationDelay: `${delayStart + (i * 0.1)}s` }}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col font-sans">
      {/* Injecting keyframes locally for the wave animation */}
      <style>{`
        @keyframes wave {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); } /* Default (mobile) wave height */
        }
        @media (min-width: 768px) { /* Medium screens and up */
          @keyframes wave {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); } /* Larger wave for desktop headings */
          }
        }
        .animate-wave {
          animation: wave 2s ease-in-out infinite;
        }
      `}</style>
      
      {/* 1. HERO SECTION */}
      <div className="relative h-[450px] flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
             <img 
                src="https://images.unsplash.com/photo-1505664194779-8beaceb93744?q=80&w=2070&auto=format&fit=crop" 
                alt="Global Legal Services" 
                className="w-full h-full object-cover"
             />
             <div className="absolute inset-0 bg-blue-950/70 mix-blend-multiply"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 w-full max-w-5xl px-4 text-center">
             <div className="mb-6 flex flex-col items-center justify-center">
                 <h1 className="text-2xl md:text-4xl font-bold text-white mb-2 drop-shadow-xl font-serif tracking-tight">
                    Global Legal Expertise on
                 </h1>
                 {/* Waving Domain Name */}
                 <div className="flex items-center justify-center text-3xl md:text-6xl font-bold font-serif tracking-tight gap-1 md:gap-2"> {/* Responsive gap */}
                    <WavyText 
                        text="LawyerOnline" 
                        className="" 
                        colorClass="text-white"
                    />
                    <WavyText 
                        text=".LIVE" 
                        className="" 
                        delayStart={1.2} 
                        colorClass="text-red-500"
                    />
                 </div>
             </div>

             <p className="text-lg md:text-xl text-blue-100 mb-10 max-w-3xl mx-auto drop-shadow font-light leading-relaxed">
                Connect with verified advocates & legal consultants worldwide in real-time. <br className="hidden md:block"/> Secure, fast, and globally accessible.
             </p>

             {/* Search Filter */}
             <div className="bg-white/10 backdrop-blur-md border border-white/20 p-4 rounded-2xl shadow-2xl grid grid-cols-1 md:grid-cols-4 gap-3 max-w-4xl mx-auto">
                 
                 {/* Country Dropdown */}
                 <div className="relative">
                     <select 
                        className="w-full h-12 px-4 rounded-lg bg-white border-0 focus:ring-2 focus:ring-amber-500 text-slate-800 font-medium appearance-none text-sm shadow-sm"
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                     >
                         <option value="">Select Country</option>
                         {availableCountries.map(c => <option key={c.code} value={c.name}>{c.name}</option>)}
                     </select>
                     <div className="absolute right-3 top-4 pointer-events-none text-slate-400">
                         <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                     </div>
                 </div>

                 {/* City Dropdown */}
                 <div className="relative">
                     <select 
                        className="w-full h-12 px-4 rounded-lg bg-white border-0 focus:ring-2 focus:ring-amber-500 text-slate-800 font-medium appearance-none disabled:opacity-60 text-sm shadow-sm"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        disabled={!country}
                     >
                         <option value="">Select City</option>
                         {availableCities.map(c => <option key={c} value={c}>{c}</option>)}
                     </select>
                     <div className="absolute right-3 top-4 pointer-events-none text-slate-400">
                         <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                     </div>
                 </div>

                 {/* Specialty Dropdown */}
                 <div className="relative">
                    <select 
                      className="w-full h-12 px-4 rounded-lg bg-white border-0 focus:ring-2 focus:ring-amber-500 text-slate-800 font-medium appearance-none text-sm shadow-sm"
                      value={specialty}
                      onChange={(e) => setSpecialty(e.target.value)}
                    >
                      <option value="">Select Specialty</option>
                      <option value="Family Law">Family Law</option>
                      <option value="Criminal Law">Criminal Law</option>
                      <option value="Corporate Law">Corporate Law</option>
                      <option value="Tax Law">Tax Law</option>
                      <option value="Civil Litigation">Civil Litigation</option>
                      <option value="Immigration">Immigration</option>
                      <option value="Real Estate">Real Estate</option>
                      <option value="Environmental Law">Environmental Law</option>
                      <option value="Intellectual Property">Intellectual Property</option>
                      <option value="Labor Law">Labor Law</option>
                      <option value="Constitutional Law">Constitutional Law</option>
                      <option value="Banking & Finance">Banking & Finance</option>
                    </select>
                    <div className="absolute right-3 top-4 pointer-events-none text-slate-400">
                         <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                     </div>
                 </div>
                 
                 <button 
                  onClick={handleSearch}
                  className="w-full h-12 bg-amber-500 hover:bg-amber-400 text-blue-950 font-bold rounded-lg shadow-lg transition transform hover:scale-105 text-sm uppercase tracking-wider"
                 >
                  Find Lawyers
                 </button>
             </div>
        </div>
      </div>

      {/* 2. MARQUEE SECTION */}
      <div className="py-12 bg-slate-50 overflow-hidden border-b border-slate-200">
          <div className="container mx-auto px-4 mb-8 text-center">
              <h2 className="text-2xl md:text-3xl font-bold text-blue-950 font-serif flex justify-center items-center gap-1 md:gap-2"> {/* Responsive gap */}
                Top Verified Experts on 
                <WavyText 
                    text="LawyerOnline" 
                    className="" 
                    colorClass="text-blue-950"
                    delayStart={0.5} // Slightly delayed wave
                />
                <WavyText 
                    text=".LIVE" 
                    className="" 
                    delayStart={1.0} 
                    colorClass="text-red-500"
                />
              </h2>
              <div className="w-16 h-1 bg-amber-500 mx-auto mt-3 rounded"></div>
          </div>

          <div className="relative w-full">
               <div className="flex animate-scroll whitespace-nowrap px-4" style={{ animation: `scroll ${lawyers.length * 1.5}s linear infinite` }}>
                   {[...lawyers, ...lawyers].map((lawyer, idx) => (
                       <div key={`${lawyer.uid}-${idx}`} className="inline-block shrink-0 w-[180px] h-[120px] md:w-[240px] md:h-[140px] bg-white rounded-xl shadow-md mx-3 relative group hover:shadow-xl transition-all overflow-hidden border border-slate-100 hover:border-amber-200">
                           
                           <div className="flex h-full">
                               {/* Left Column */}
                               <div className="w-[60px] md:w-[80px] bg-slate-50 flex flex-col items-center justify-center p-2 border-r border-slate-100 shrink-0">
                                    <div className="relative">
                                        <img 
                                            src={lawyer.picture || appLogoUrl || DEFAULT_LOGO_SVG} 
                                            alt={lawyer.fullName} 
                                            className="w-10 h-10 md:w-12 md:h-12 rounded-full object-cover border-2 border-white shadow-sm mb-1"
                                            onError={(e) => { 
                                                const img = e.currentTarget;
                                                img.onerror = null; // STOP INFINITE LOOP
                                                img.src = 'data:,'; // Set to empty data URL to stop browser attempts
                                                setTimeout(() => img.src = DEFAULT_LOGO_SVG, 0); // Delay to ensure 'data:,' takes effect
                                            }}
                                        />
                                        {lawyer.isVerified && (
                                            <div className="absolute bottom-1 right-0 bg-blue-600 text-white rounded-full p-0.5 border border-white shadow-sm">
                                                <svg className="w-2.5 h-2.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                                            </div>
                                        )}
                                    </div>
                                    <div className="text-center w-full">
                                        <p className="text-[8px] md:text-[9px] font-bold text-slate-700 leading-tight truncate px-1">{lawyer.city || 'City'}</p>
                                        <p className="text-[8px] md:text-[9px] text-slate-500 leading-tight truncate px-1">{lawyer.country || 'Country'}</p>
                                        <img 
                                          src={getFlagUrl(lawyer.country)} 
                                          alt="flag" 
                                          className="w-6 h-auto mt-1 mx-auto shadow-sm opacity-[0.08]" // Set opacity low, was higher in earlier iteration
                                          onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')}
                                        />
                                    </div>
                               </div>

                               {/* Right Column */}
                               <div className="flex-grow p-3 relative flex flex-col justify-center bg-white">
                                    <div className="absolute inset-0 opacity-[0.08] bg-no-repeat bg-cover bg-center pointer-events-none" style={{backgroundImage: `url(${getFlagUrl(lawyer.country)})`}}></div>
                                    
                                    <div className="relative z-10 text-left whitespace-normal">
                                        <h3 className="font-bold text-xs md:text-sm text-blue-900 line-clamp-2 font-serif leading-tight mb-1" title={lawyer.fullName}>{lawyer.fullName}</h3>
                                        <p className="text-[7px] md:text-[8px] font-bold text-amber-600 uppercase tracking-wide mb-2 truncate">
                                            {lawyer.specialties && lawyer.specialties.length > 0 ? lawyer.specialties[0] : 'General Practice'}
                                        </p>
                                        
                                        <div className="flex items-center text-amber-500 text-[8px] md:text-[9px] mb-3">
                                            {'★'.repeat(Math.round(lawyer.rating || 0))} 
                                            {'☆'.repeat(5 - Math.round(lawyer.rating || 0))} 
                                            <span className="text-slate-400 ml-1 font-medium">({lawyer.reviewCount || 0})</span>
                                        </div>

                                        <Link 
                                            to={`/lawyer/${lawyer.uid}`}
                                            className="text-[8px] md:text-[9px] bg-blue-950 text-white px-3 py-1.5 rounded hover:bg-blue-900 transition-colors shadow-sm inline-block font-medium"
                                        >
                                            View Profile
                                        </Link>
                                    </div>
                               </div>
                           </div>
                           
                           <Link to={`/lawyer/${lawyer.uid}`} className="absolute inset-0 z-20" aria-label={`View profile of ${lawyer.fullName}`}></Link>
                       </div>
                   ))}
               </div>
          </div>
          <style>{`
            @keyframes scroll {
                0% { transform: translateX(0); }
                100% { transform: translateX(-50%); }
            }
          `}</style>
      </div>

      {/* 3. PLATFORM TOOLS */}
      <div className="py-12 bg-white border-b border-slate-100">
          <div className="container mx-auto px-4">
              <div className="flex flex-col items-center justify-center">
                   <span className="font-bold text-slate-400 uppercase text-xs tracking-widest mb-6">Platform Tools</span>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-4 w-full max-w-4xl text-sm">
                       {/* Column 1 */}
                       <div className="flex flex-col space-y-3">
                           <Link to="/login" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">My Dashboard</span>
                           </Link>
                           <Link to="/find-lawyers" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">Verify Lawyer License</span>
                           </Link>
                       </div>

                       {/* Column 2 */}
                       <div className="flex flex-col space-y-3">
                           <Link to="/signup" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">Register as a Lawyer</span>
                           </Link>
                           <Link to="/dashboard/client" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">Check My Case Status</span>
                           </Link>
                       </div>

                       {/* Column 3 */}
                       <div className="flex flex-col space-y-3">
                           <Link to="/find-lawyers" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">Legal Advice for Startups</span>
                           </Link>
                           <Link to="/find-lawyers" className="flex items-center group text-slate-600 hover:text-amber-600 transition justify-start">
                               <svg className="w-4 h-4 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
                               <span className="group-hover:translate-x-1 transition-transform font-medium">Consumer Rights Protection</span>
                           </Link>
                       </div>
                   </div>
              </div>
          </div>

      {/* 4. ARTICLES SECTION */}
      <div className="py-16 bg-white" id="articles-section">
          <div className="container mx-auto px-4">
              <div className="flex justify-between items-end mb-10 border-b border-slate-100 pb-4">
                  <div>
                      <h2 className="text-3xl font-bold text-blue-950 font-serif flex items-center gap-1 md:gap-2"> {/* Responsive gap */}
                        Latest Legal Insights on
                        <WavyText 
                            text="LawyerOnline" 
                            className="" 
                            colorClass="text-blue-950"
                            delayStart={0.5} // Slightly delayed wave
                        />
                        <WavyText 
                            text=".LIVE" 
                            className="" 
                            delayStart={1.0} 
                            colorClass="text-red-500"
                        />
                      </h2>
                      <p className="text-slate-500 text-sm mt-1">Read news and guides from international legal experts.</p>
                  </div>
              </div>

              {loadingArticles ? (
                <div className="flex justify-center py-12">
                   <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-900"></div>
                </div>
              ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {articles.length === 0 ? (
                        <div className="col-span-full text-center py-12 bg-slate-50 rounded-lg border border-dashed border-slate-300">
                            <p className="text-slate-500">No articles available at the moment.</p>
                        </div>
                    ) : (
                        articles.slice(0, 4).map(article => (
                            <Link to={`/articles/${article.slug}`} key={article.id} className="group flex flex-col h-full border border-slate-100 rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300 bg-white">
                                <div className="h-44 overflow-hidden bg-slate-200 relative">
                                    <img 
                                        src={article.featuredImage || appLogoUrl || DEFAULT_LOGO_SVG} 
                                        alt={article.title} 
                                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                                        onError={(e) => { 
                                            const img = e.currentTarget;
                                            img.onerror = null; // STOP INFINITE LOOP
                                            img.src = 'data:,'; // Set to empty data URL to stop browser attempts
                                            setTimeout(() => img.src = DEFAULT_LOGO_SVG, 0); // Delay to ensure 'data:,' takes effect
                                        }}
                                    />
                                    <div className="absolute top-3 right-3 bg-blue-950/90 backdrop-blur px-3 py-1 rounded text-[10px] font-bold text-amber-400 uppercase tracking-wide border border-blue-900 shadow-sm">
                                        Legal Insight
                                    </div>
                                </div>
                                <div className="p-5 flex flex-col flex-grow">
                                    <div className="text-[10px] text-slate-400 mb-2 flex items-center space-x-2 font-medium uppercase tracking-wider">
                                        <span className="text-amber-600">{article.date}</span>
                                        <span>&bull;</span>
                                        <span>By {article.author}</span>
                                    </div>
                                    <h3 className="font-bold text-lg text-slate-900 mb-2 group-hover:text-blue-700 transition-colors line-clamp-2 font-serif">{article.title}</h3>
                                    <p className="text-sm text-slate-600 line-clamp-3 mb-4 flex-grow leading-relaxed">{article.description}</p>
                                    <span className="text-amber-600 text-xs font-bold uppercase tracking-wider group-hover:text-amber-500 flex items-center">
                                        Read Article 
                                        <svg className="w-3 h-3 ml-1 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                                    </span>
                                </div>
                            </Link>
                        ))
                    )}
                  </div>
              )}
          </div>
      </div>

      {/* 5. CTA SECTION */}
      <div className="bg-blue-950 py-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
          <div className="container mx-auto px-4 relative z-10 text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 font-serif flex justify-center items-center gap-1 md:gap-2"> {/* Responsive gap */}
                <WavyText 
                    text="LawyerOnline" 
                    className="" 
                    colorClass="text-white"
                    delayStart={0.3} 
                />
                <WavyText 
                    text=".LIVE" 
                    className="" 
                    delayStart={0.8} 
                    colorClass="text-red-500"
                /> 
                for Professionals
              </h2>
              <p className="text-blue-100 mb-10 max-w-2xl mx-auto text-lg leading-relaxed">
                  Join the elite global network. Get your verified badge, use AI drafting tools, and manage international clients seamlessly.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <Link to="/signup" className="bg-amber-500 text-blue-950 px-8 py-4 rounded-lg font-bold hover:bg-amber-400 transition shadow-lg transform hover:-translate-y-1 text-sm uppercase tracking-wider">
                      Join as a Lawyer
                  </Link>
                  <Link to="/find-lawyers" className="border-2 border-blue-400 text-blue-100 px-8 py-4 rounded-lg font-bold hover:bg-blue-900 hover:border-blue-300 transition text-sm uppercase tracking-wider">
                      Search Lawyers
                  </Link>
              </div>
          </div>
      </div>
    </div>
  );
}