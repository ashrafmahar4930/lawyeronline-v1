

import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getLawyerProfile, getReviews, addReview, getAppLogoUrl, DEFAULT_LOGO_SVG, toggleFavorite, checkIfFavorite, logConsultation, addBooking } from '../services/mockDataService';
import { LawyerProfile, Review, ConsultationLog, Booking } from '../types';
import { useAuth } from '../App';
import { updateMeta } from '../utils/seo';

export default function LawyerProfilePage() {
  const { uid } = useParams<{ uid: string }>();
  const [profile, setProfile] = useState<LawyerProfile | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);
  
  // Review Form State
  const { user } = useAuth();
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  // Favorite State
  const [isFavorite, setIsFavorite] = useState(false);
  const [togglingFavorite, setTogglingFavorite] = useState(false);
  
  // Booking Modal State
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingNotes, setBookingNotes] = useState('');
  const [isBookingSubmitting, setIsBookingSubmitting] = useState(false);


  useEffect(() => {
    const fetchProfile = async () => {
      if (uid) {
        const data = await getLawyerProfile(uid);
        setProfile(data || null);
        const reviewsData = await getReviews(uid);
        setReviews(reviewsData);
        const logo = await getAppLogoUrl();
        setAppLogoUrl(logo);

        if (user && user.role === 'client' && data) {
            const favStatus = await checkIfFavorite(user.uid, data.uid);
            setIsFavorite(favStatus);
        }

        if (data) {
            // Dynamic SEO for Lawyer Profile
            updateMeta({
                title: `${data.title} ${data.fullName} - ${data.specialties?.[0] || 'Lawyer'} in ${data.city}`,
                description: `Hire ${data.fullName}, a verified ${data.title} specializing in ${data.specialties?.join(', ')}. Located in ${data.city}, ${data.country}. Book a consultation on LawyerOnline.LIVE.`,
                image: data.picture,
                url: `https://www.lawyeronline.live/lawyer/${data.uid}`,
                schema: {
                    "@context": "https://schema.org",
                    "@type": "Attorney",
                    "name": data.fullName,
                    "jobTitle": data.title,
                    "image": data.picture || DEFAULT_LOGO_SVG,
                    "address": {
                        "@type": "PostalAddress",
                        "addressLocality": data.city,
                        "addressCountry": data.country
                    },
                    "telephone": data.contactMobile,
                    "aggregateRating": {
                        "@type": "AggregateRating",
                        "ratingValue": data.rating || 5,
                        "reviewCount": data.reviewCount || 1
                    }
                }
            });
        }
      }
      setLoading(false);
    };
    fetchProfile();
  }, [uid, user]); // Depend on user to re-check favorite status if login state changes

  const handleSubmitReview = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user || !profile || !uid) return;

      setSubmittingReview(true);
      try {
          const review: Review = {
              id: `rev_${Date.now()}`,
              lawyerId: uid,
              clientId: user.uid,
              clientName: user.displayName || 'Anonymous Client',
              rating: newRating,
              comment: newComment,
              createdAt: new Date().toISOString()
          };
          
          await addReview(review);
          
          // Update local state
          setReviews([review, ...reviews]);
          setNewComment('');
          setNewRating(5);
          
          // Simple optimistic update for profile stats
          setProfile(prev => prev ? ({
              ...prev,
              rating: Math.round((((prev.rating || 0) * (prev.reviewCount || 0) + review.rating) / ((prev.reviewCount || 0) + 1)) * 10) / 10,
              reviewCount: (prev.reviewCount || 0) + 1
          }) : null);

          alert("Review submitted successfully!");
      } catch (error) {
          console.error("Failed to submit review", error);
          alert("Failed to submit review.");
      } finally {
          setSubmittingReview(false);
      }
  };

  const handleToggleFavorite = async () => {
      if (!user || user.role !== 'client' || !profile) {
          alert("Please login as a client to save lawyers to your favorites.");
          return;
      }
      setTogglingFavorite(true);
      try {
          const newStatus = await toggleFavorite(user.uid, profile.uid, profile.fullName);
          setIsFavorite(newStatus);
          alert(newStatus ? `${profile.fullName} added to your favorites!` : `${profile.fullName} removed from your favorites.`);
      } catch (error) {
          console.error("Failed to toggle favorite:", error);
          alert("Failed to update favorite status.");
      } finally {
          setTogglingFavorite(false);
      }
  };

  const handleContactClick = async (method: ConsultationLog['contactMethod']) => {
      if (user && user.role === 'client' && profile) {
          await logConsultation(user.uid, profile.uid, profile.fullName, method);
      } else if (!user) {
          alert("Please login to contact the lawyer.");
      }
  };
  
  const handleBookAppointment = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!user || !profile) return;
      
      setIsBookingSubmitting(true);
      try {
          const booking: Booking = {
              id: `book_${Date.now()}`,
              lawyerId: profile.uid,
              lawyerName: profile.fullName,
              clientId: user.uid,
              clientName: user.displayName || 'Client',
              clientEmail: user.email || '',
              date: bookingDate,
              time: bookingTime,
              status: 'pending',
              notes: bookingNotes,
              createdAt: new Date().toISOString()
          };
          
          await addBooking(booking);
          alert("Appointment request sent successfully! The lawyer will confirm shortly.");
          setIsBookingModalOpen(false);
          setBookingDate('');
          setBookingTime('');
          setBookingNotes('');
      } catch (error) {
          console.error("Booking failed:", error);
          alert("Failed to book appointment. Please try again.");
      } finally {
          setIsBookingSubmitting(false);
      }
  };


  if (loading) return <div className="p-20 text-center text-slate-500">Loading profile...</div>;
  if (!profile) return <div className="p-20 text-center text-slate-500">Lawyer not found.</div>;

  const flagUrl = `https://flagcdn.com/w320/${profile.country === 'Pakistan' ? 'pk' : 'pk'}.png`; // Simple mock logic for flag

  // Construct WhatsApp Booking Link
  const bookingMessage = `Hello ${profile.title} ${profile.fullName}, I found your profile on LawyerOnline and would like to book a professional consultation. Please let me know your availability.`;
  
  // Clean phone number for WhatsApp link (remove +, spaces, dashes)
  const cleanPhone = profile.contactWhatsapp ? profile.contactWhatsapp.replace(/[^0-9]/g, '') : '';
  
  const whatsappLink = cleanPhone 
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(bookingMessage)}`
    : '#';

  const handleWhatsAppClick = (e: React.MouseEvent) => {
      if (!cleanPhone) {
          e.preventDefault();
          alert("This lawyer has not provided a WhatsApp number for bookings.");
      } else {
          handleContactClick('whatsapp');
      }
  };

  const handleCallClick = (e: React.MouseEvent) => {
      if (!profile.contactMobile) {
          e.preventDefault();
          alert("This lawyer has not provided a mobile number for calls.");
      } else {
          handleContactClick('call');
      }
  };

  const handleEmailClick = (e: React.MouseEvent) => {
      if (!profile.contactEmail) {
          e.preventDefault();
          alert("This lawyer has not provided an email address.");
      } else {
          handleContactClick('email');
      }
  };


  return (
    <div className="bg-slate-50 min-h-screen pb-12">
      {/* Banner */}
      <div className="h-48 bg-blue-900 relative overflow-hidden">
          <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
          <div className="container mx-auto px-4 h-full flex items-end pb-4">
              {/* Optional: Add breadcrumb or back link here */}
          </div>
      </div>

      <div className="container mx-auto px-4 -mt-16 relative z-10">
        <div className="bg-white rounded-xl shadow-lg border border-slate-100 overflow-hidden">
            <div className="flex flex-col md:flex-row">
                {/* Sidebar / Image */}
                <div className="w-full md:w-80 bg-slate-50 p-8 text-center border-r border-slate-100">
                    <div className="w-40 h-40 mx-auto bg-white p-1 rounded-full shadow-md mb-4 relative flex items-center justify-center overflow-hidden">
                        <img 
                            src={profile.picture || appLogoUrl || DEFAULT_LOGO_SVG} 
                            alt={profile.fullName} 
                            className="w-full h-full rounded-full object-cover"
                            onError={(e) => { 
                                const img = e.currentTarget;
                                img.onerror = null; // STOP INFINITE LOOP
                                img.src = DEFAULT_LOGO_SVG; 
                            }}
                        />
                        {profile.isVerified && (
                            <div className="absolute bottom-2 right-2 bg-blue-600 text-white p-1.5 rounded-full border-4 border-slate-50 shadow-sm" title="Verified Lawyer">
                                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                            </div>
                        )}
                        {/* Favorite Button */}
                        {user && user.role === 'client' && (
                             <button 
                                 onClick={handleToggleFavorite}
                                 disabled={togglingFavorite}
                                 className={`absolute top-2 right-2 p-2 rounded-full shadow-md transition-all ${isFavorite ? 'bg-red-500 text-white' : 'bg-white text-red-500 hover:bg-red-50'}`}
                                 title={isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                             >
                                 <svg className="w-6 h-6" fill={isFavorite ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={isFavorite ? "0" : "2"} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" fillRule={isFavorite ? "evenodd" : "nonzero"} /></svg>
                             </button>
                         )}
                    </div>
                    
                    <div className="flex justify-center items-center gap-2 mb-6 opacity-80">
                        <img src={flagUrl} alt="flag" className="w-5 h-auto" onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')} />
                        <span className="text-slate-600 text-sm font-medium">{profile.city}, {profile.country}</span>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-col gap-2 mb-3">
                         {/* Call Button */}
                         <a 
                            href={profile.contactMobile ? `tel:${profile.contactMobile}` : '#'}
                            onClick={handleCallClick}
                            className={`block w-full text-white font-bold py-3 px-4 rounded-lg shadow transition-colors flex items-center justify-center gap-2 ${profile.contactMobile ? 'bg-blue-600 hover:bg-blue-700' : 'bg-slate-300 cursor-not-allowed'}`}
                        >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                            Call Lawyer
                        </a>

                        {/* WhatsApp Button */}
                        <a 
                            href={whatsappLink}
                            target="_blank"
                            rel="noreferrer"
                            onClick={handleWhatsAppClick}
                            className="block w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg shadow transition-colors flex items-center justify-center gap-2"
                        >
                            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
                            WhatsApp
                        </a>

                         {/* Email Button */}
                         <a 
                            href={profile.contactEmail ? `mailto:${profile.contactEmail}` : '#'}
                            onClick={handleEmailClick}
                            className={`block w-full text-white font-bold py-3 px-4 rounded-lg shadow transition-colors flex items-center justify-center gap-2 ${profile.contactEmail ? 'bg-slate-700 hover:bg-slate-800' : 'bg-slate-300 cursor-not-allowed'}`}
                        >
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                            Email Lawyer
                        </a>
                    </div>

                    <p className="text-xs text-slate-400">Usually replies within an hour</p>
                </div>

                {/* Content Area */}
                <div className="flex-grow p-8">
                    <div className="flex flex-col md:flex-row justify-between items-start mb-4 gap-4">
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900 font-serif mb-1">{profile.fullName}</h1>
                            <p className="text-blue-600 font-semibold text-lg">{profile.title}</p>
                        </div>
                        <div className="text-right flex flex-col items-end gap-2">
                            <div className="inline-flex items-center bg-amber-50 px-3 py-1 rounded-full border border-amber-100">
                                <span className="text-amber-500 text-lg mr-1">★</span>
                                <span className="font-bold text-slate-800">{profile.rating || '5.0'}</span>
                                <span className="text-slate-400 text-sm ml-1">({profile.reviewCount || 0} reviews)</span>
                            </div>
                            <button 
                                onClick={() => user ? setIsBookingModalOpen(true) : alert('Please login to book a consultation.')}
                                className="bg-amber-500 hover:bg-amber-400 text-blue-900 font-bold px-6 py-2 rounded-full shadow-lg transform hover:-translate-y-0.5 transition"
                            >
                                Book Consultation
                            </button>
                        </div>
                    </div>

                    {/* Badges/Specialties */}
                    <div className="mb-8 flex flex-wrap gap-2">
                        {profile.specialties && profile.specialties.map((spec, index) => (
                            <span key={index} className="bg-slate-100 text-slate-700 px-3 py-1 rounded-full text-sm font-medium uppercase tracking-wide">{spec}</span>
                        ))}
                        {(!profile.specialties || profile.specialties.length === 0) && (
                            <span className="bg-slate-100 text-slate-700 px-3 py-1 rounded-full text-sm font-medium uppercase tracking-wide">General Practice</span>
                        )}
                        {profile.officeName && <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium border border-blue-100">{profile.officeName}</span>}
                    </div>

                    {/* About Section */}
                    <div className="mb-8">
                        <h3 className="text-lg font-bold text-slate-900 mb-3 border-b pb-2">About Me</h3>
                        <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{profile.aboutMe || "No bio provided."}</p>
                    </div>

                    {/* Info Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 mb-3 border-b pb-2">Education & License</h3>
                            <ul className="space-y-3 text-slate-700">
                                <li className="flex">
                                    <svg className="w-5 h-5 text-slate-400 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /></svg>
                                    <span>{profile.degreeName || 'N/A'} <span className="text-slate-400 text-sm block">{profile.issuingAuthority}</span></span>
                                </li>
                                <li className="flex items-center">
                                    <svg className="w-5 h-5 text-slate-400 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0c0 .884-.956 2.943-2 3M16.838 6.786C15.23 8.102 12 8 12 8" /></svg>
                                    <span>License: <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-sm">{profile.licenseNumber || 'N/A'}</span></span>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 mb-3 border-b pb-2">Achievements</h3>
                            <div className="text-slate-700 leading-relaxed">
                                {profile.achievements ? (
                                    <p>{profile.achievements}</p>
                                ) : (
                                    <p className="text-slate-400 italic">No specific achievements listed.</p>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Contact Details (Non-Sensitive) */}
                    <div className="mb-12">
                        <h3 className="text-lg font-bold text-slate-900 mb-3 border-b pb-2">Office Location</h3>
                        <div className="flex items-start text-slate-700">
                            <svg className="w-5 h-5 text-slate-400 mr-3 mt-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                            <span>{profile.officeAddress || 'Address not publicly listed'}</span>
                        </div>
                    </div>

                    {/* REVIEWS SECTION */}
                    <div className="mt-10 pt-10 border-t border-slate-200">
                        <h3 className="text-2xl font-bold text-slate-900 mb-6">Client Reviews</h3>
                        
                        {/* Add Review Form - Only for Clients */}
                        {user && user.role === 'client' ? (
                            <form onSubmit={handleSubmitReview} className="bg-slate-50 p-6 rounded-lg mb-8 border border-slate-200">
                                <h4 className="font-bold text-lg mb-4">Leave a Review</h4>
                                <div className="mb-4">
                                    <label className="block text-sm font-medium mb-1">Rating</label>
                                    <div className="flex gap-2">
                                        {[1, 2, 3, 4, 5].map(num => (
                                            <button 
                                                key={num} 
                                                type="button"
                                                onClick={() => setNewRating(num)}
                                                className={`text-2xl ${num <= newRating ? 'text-amber-400' : 'text-slate-300'}`}
                                            >
                                                ★
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="mb-4">
                                    <label className="block text-sm font-medium mb-1">Your Experience</label>
                                    <textarea 
                                        className="w-full border p-3 rounded" 
                                        rows={3} 
                                        placeholder="Share your experience with this lawyer..."
                                        value={newComment}
                                        onChange={e => setNewComment(e.target.value)}
                                        required
                                    />
                                </div>
                                <button 
                                    type="submit" 
                                    disabled={submittingReview}
                                    className="bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700 disabled:bg-slate-400"
                                >
                                    {submittingReview ? 'Submitting...' : 'Submit Review'}
                                </button>
                            </form>
                        ) : (
                            !user && (
                                <div className="bg-slate-50 p-4 rounded mb-8 text-center text-sm">
                                    <Link to="/login" className="text-blue-600 hover:underline font-bold">Login as a Client</Link> to leave a review.
                                </div>
                            )
                        )}

                        {/* Reviews List */}
                        <div className="space-y-6">
                            {reviews.length === 0 ? (
                                <p className="text-slate-500 italic">No reviews yet. Be the first to review!</p>
                            ) : (
                                reviews.map(review => (
                                    <div key={review.id} className="border-b border-slate-100 pb-6 last:border-0">
                                        <div className="flex justify-between items-center mb-2">
                                            <div className="flex items-center gap-2">
                                                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-xs">
                                                    {review.clientName.charAt(0).toUpperCase()}
                                                </div>
                                                <span className="font-bold text-slate-800">{review.clientName}</span>
                                            </div>
                                            <span className="text-slate-400 text-xs">{new Date(review.createdAt).toLocaleDateString()}</span>
                                        </div>
                                        <div className="flex items-center text-amber-400 text-sm mb-2">
                                            {'★'.repeat(review.rating)}
                                            {'☆'.repeat(5 - review.rating)}
                                        </div>
                                        <p className="text-slate-700 text-sm leading-relaxed">{review.comment}</p>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                </div>
            </div>
        </div>
      </div>

      {/* Booking Modal */}
      {isBookingModalOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
              <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
                  <div className="bg-blue-900 text-white p-4 flex justify-between items-center">
                      <h3 className="font-bold text-lg">Book Consultation</h3>
                      <button onClick={() => setIsBookingModalOpen(false)} className="text-blue-200 hover:text-white">
                          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                      </button>
                  </div>
                  <form onSubmit={handleBookAppointment} className="p-6">
                      <p className="text-sm text-slate-600 mb-4">Request an appointment with <strong>{profile.fullName}</strong>. The lawyer will review and confirm your request.</p>
                      
                      <div className="mb-4">
                          <label className="block text-sm font-medium mb-1 text-slate-700">Preferred Date</label>
                          <input 
                              type="date" 
                              required 
                              className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                              value={bookingDate}
                              onChange={e => setBookingDate(e.target.value)}
                              min={new Date().toISOString().split('T')[0]}
                          />
                      </div>
                      
                      <div className="mb-4">
                          <label className="block text-sm font-medium mb-1 text-slate-700">Preferred Time</label>
                          <input 
                              type="time" 
                              required 
                              className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                              value={bookingTime}
                              onChange={e => setBookingTime(e.target.value)}
                          />
                      </div>
                      
                      <div className="mb-6">
                          <label className="block text-sm font-medium mb-1 text-slate-700">Purpose / Reason</label>
                          <textarea 
                              rows={3} 
                              required 
                              placeholder="Briefly describe your legal issue..." 
                              className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
                              value={bookingNotes}
                              onChange={e => setBookingNotes(e.target.value)}
                          />
                      </div>
                      
                      <button 
                          type="submit" 
                          disabled={isBookingSubmitting}
                          className="w-full bg-amber-500 hover:bg-amber-400 text-blue-900 font-bold py-3 rounded-lg shadow transition"
                      >
                          {isBookingSubmitting ? 'Sending Request...' : 'Confirm Request'}
                      </button>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
}