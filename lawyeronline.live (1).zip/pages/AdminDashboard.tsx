

import React, { useState, useEffect } from 'react';
import { VerificationRequest, Article, LawyerProfile } from '../types';
import * as db from '../services/mockDataService';
import { generateArticle } from '../services/geminiService';
import { compressImage } from '../utils/imageUtils'; 

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<'verifications' | 'articles' | 'users' | 'settings'>('verifications');
  const [requests, setRequests] = useState<VerificationRequest[]>([]);
  const [lawyers, setLawyers] = useState<LawyerProfile[]>([]);
  
  // Article State
  const [articleTopic, setArticleTopic] = useState('');
  const [articleContent, setArticleContent] = useState('');
  const [articleDesc, setArticleDesc] = useState('');
  const [articleImage, setArticleImage] = useState(''); 
  const [isGenerating, setIsGenerating] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);

  // Article CMS states
  const [currentArticles, setCurrentArticles] = useState<Article[]>([]);
  const [isLoadingArticles, setIsLoadingArticles] = useState(false);

  // App Settings State (for Logo)
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [logoFeedback, setLogoFeedback] = useState<string | null>(null);

  // Delete States
  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set());
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null); 


  useEffect(() => {
    refreshData();
    fetchArticles();
    fetchAppLogo();
  }, []);

  const refreshData = async () => {
    console.log("AdminDashboard: Refreshing all data...");
    setRequests(await db.getPendingVerifications());
    setLawyers(await db.getAllLawyers());
    console.log("AdminDashboard: Data refreshed.");
  };

  const fetchArticles = async () => {
    setIsLoadingArticles(true);
    console.log("AdminDashboard: Fetching articles...");
    const articles = await db.getArticles();
    setCurrentArticles(articles);
    setIsLoadingArticles(false);
    console.log("AdminDashboard: Articles fetched.");
  }

  const fetchAppLogo = async () => {
    console.log("AdminDashboard: Fetching app logo...");
    const url = await db.getAppLogoUrl();
    setAppLogoUrl(url);
    console.log("AdminDashboard: App logo fetched:", url);
  };


  const handleVerify = async (id: string, approve: boolean) => {
    try {
      if (approve) {
          await db.processVerification(id, 'approved');
          alert("Verification approved successfully!");
      } else {
          const reason = prompt("Verification application rejected? Enter reason:");
          if (reason) {
              await db.processVerification(id, 'rejected', reason);
              alert("Verification rejected successfully. Reason sent to lawyer.");
          } else {
              alert("Rejection cancelled: No reason provided.");
              return;
          }
      }
      refreshData();
    } catch (error: any) {
        console.error("Error verifying:", error);
        alert("Failed to process verification: " + (error.message || "Unknown error."));
    }
  };

  const requestDelete = (id: string, action: () => void) => {
      if (confirmDeleteId === id) {
          action();
          setConfirmDeleteId(null);
      } else {
          setConfirmDeleteId(id);
          setTimeout(() => setConfirmDeleteId(null), 3000);
      }
  };

  const executeDeleteUser = async (uid: string) => {
      console.log(`Attempting to delete user: ${uid}`);
      setDeletingIds(prev => new Set(prev).add(uid));

      try {
          setLawyers(prev => prev.filter(l => l.uid !== uid));
          
          await db.deleteLawyerProfile(uid); 
          alert("✅ User profile and all associated data deleted successfully.");
          console.log(`User ${uid} successfully deleted from backend.`);
          
          refreshData();
      } catch (error: any) {
          console.error("❌ Delete user failed:", error);
          refreshData(); 
          alert(`❌ Failed to delete user: ${error.message || "Unknown error. Please check Firebase permissions and logs."}`);
      } finally {
          setDeletingIds(prev => {
              const next = new Set(prev);
              next.delete(uid);
              return next;
          });
      }
  };

  const handleGenerateArticle = async () => {
      setIsGenerating(true);
      const content = await generateArticle(articleTopic);
      setArticleContent(content);
      setArticleDesc(content.substring(0, Math.min(content.length, 150)) + (content.length > 150 ? "..." : ""));
      setIsGenerating(false);
  };
  
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      if(e.target.files && e.target.files[0]) {
          try {
              setUploadingImage(true);
              const originalFile = e.target.files[0];
              const compressedFile = await compressImage(originalFile, 1200, 800, 0.8); 

              const path = `article-images/${Date.now()}_${compressedFile.name}`;
              const oldImageUrl = editingArticleId ? articleImage : undefined; 
              const url = await db.uploadFile(compressedFile, path, oldImageUrl);
              setArticleImage(url);
              alert("Image uploaded successfully!");
          } catch (error: any) {
              // Ensure we don't access properties on an Event object improperly
              alert("Image upload failed: " + (error.message || "Unknown error occurred."));
              console.error(error);
          } finally {
              setUploadingImage(false);
              e.target.value = ''; 
          }
      }
  };

  const handlePublishArticle = async () => {
      if (!articleTopic || !articleContent) {
          alert("Article title and content are required.");
          return;
      }
      
      const articleData: Article = {
          id: editingArticleId || `art_${Date.now()}`,
          title: articleTopic,
          content: articleContent,
          description: articleDesc,
          featuredImage: articleImage || `https://picsum.photos/seed/${Date.now()}/800/400`, 
          author: 'Admin', 
          date: new Date().toLocaleDateString(),
          slug: '' 
      };

      try {
          if (editingArticleId) {
              await db.updateArticle(articleData);
              alert("✅ Article Updated!");
          } else {
              await db.addArticle(articleData);
              alert("✅ Article Published!");
          }
          
          setArticleTopic('');
          setArticleContent('');
          setArticleDesc('');
          setArticleImage('');
          setEditingArticleId(null);
          fetchArticles(); 
      } catch (error: any) {
          console.error("❌ Failed to publish/update article:", error);
          alert(`❌ Failed to publish/update article: ${error.message || "Unknown error."}`);
      }
  };

  const handleEditArticle = (article: Article) => {
    setEditingArticleId(article.id);
    setArticleTopic(article.title);
    setArticleContent(article.content);
    setArticleDesc(article.description);
    setArticleImage(article.featuredImage || '');
    window.scrollTo({ top: 0, behavior: 'smooth' }); 
  };

  const executeDeleteArticle = async (articleId: string) => {
    console.log(`Attempting to delete article: ${articleId}`);
    setDeletingIds(prev => new Set(prev).add(articleId));

    try {
        setCurrentArticles(prev => prev.filter(a => a.id !== articleId));

        await db.deleteArticle(articleId);
        alert("✅ Article deleted successfully!");
        console.log(`Article ${articleId} successfully deleted from backend.`);
        
        fetchArticles(); 
    } catch (error: any) {
        console.error("❌ Failed to delete article:", error);
        fetchArticles(); 
        alert(`❌ Failed to delete article: ${error.message || "Unknown error. Please check Firebase permissions and logs."}`);
    } finally {
        setDeletingIds(prev => {
            const next = new Set(prev);
            next.delete(articleId);
            return next;
        });
    }
  };

  const handleCancelEdit = () => {
    setEditingArticleId(null);
    setArticleTopic('');
    setArticleContent('');
    setArticleDesc('');
    setArticleImage('');
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setLogoFile(e.target.files[0]);
      setLogoFeedback(null);
    }
  };

  const handleUploadLogo = async () => {
    if (!logoFile) {
      setLogoFeedback("Please select a file to upload.");
      return;
    }
    setUploadingLogo(true);
    setLogoFeedback(null);
    try {
      const newUrl = await db.updateAppLogo(logoFile, appLogoUrl || undefined);
      setAppLogoUrl(newUrl);
      setLogoFeedback("✅ Logo uploaded successfully!");
      setLogoFile(null); 
      (document.getElementById('logoFileInput') as HTMLInputElement).value = ''; 
    } catch (error: any) {
      console.error("❌ Error uploading logo:", error);
      setLogoFeedback(`❌ Failed to upload logo: ${error.message || "Unknown error. Please check Firebase permissions."}`);
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleRemoveLogo = async () => {
    if (!appLogoUrl) {
      setLogoFeedback("No logo to remove.");
      return;
    }
    if (!window.confirm("Are you sure you want to remove the custom app logo? This cannot be undone.")) {
      return;
    }
    setUploadingLogo(true); 
    setLogoFeedback(null);
    try {
      await db.deleteAppLogo(appLogoUrl);
      setAppLogoUrl(null); 
      setLogoFeedback("✅ Logo removed successfully. Default logo will be used.");
    } catch (error: any) {
      console.error("❌ Error removing logo:", error);
      setLogoFeedback(`❌ Failed to remove logo: ${error.message || "Unknown error. Please check Firebase permissions."}`);
    } finally {
      setUploadingLogo(false);
    }
  };


  const totalVerified = lawyers.filter(l => l.isVerified).length;
  const totalSuspended = lawyers.filter(l => l.verificationStatus === 'rejected').length;
  const totalUsers = lawyers.length;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded shadow border-l-4 border-blue-600">
              <div className="text-slate-500 text-sm font-semibold uppercase">Total Lawyers</div>
              <div className="text-3xl font-bold">{totalUsers}</div>
          </div>
          <div className="bg-white p-6 rounded shadow border-l-4 border-green-600">
              <div className="text-slate-500 text-sm font-semibold uppercase">Verified Lawyers</div>
              <div className="text-3xl font-bold">{totalVerified}</div>
          </div>
          <div className="bg-white p-6 rounded shadow border-l-4 border-red-600">
              <div className="text-slate-500 text-sm font-semibold uppercase">Rejected Lawyers</div>
              <div className="text-3xl font-bold">{totalSuspended}</div>
          </div>
          <div className="bg-white p-6 rounded shadow border-l-4 border-purple-600">
              <div className="text-slate-500 text-sm font-semibold uppercase">Pending Verifications</div>
              <div className="text-3xl font-bold">{requests.length}</div>
          </div>
      </div>
      
      <div className="bg-white rounded-lg shadow min-h-[600px]">
         <div className="border-b flex overflow-x-auto">
             <button onClick={() => setActiveTab('verifications')} className={`px-6 py-4 font-medium whitespace-nowrap ${activeTab === 'verifications' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-600'}`}>Verifications ({requests.length})</button>
             <button onClick={() => setActiveTab('users')} className={`px-6 py-4 font-medium whitespace-nowrap ${activeTab === 'users' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-600'}`}>All Lawyers ({lawyers.length})</button>
             <button onClick={() => setActiveTab('articles')} className={`px-6 py-4 font-medium whitespace-nowrap ${activeTab === 'articles' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-600'}`}>CMS / Articles ({currentArticles.length})</button>
             <button onClick={() => setActiveTab('settings')} className={`px-6 py-4 font-medium whitespace-nowrap ${activeTab === 'settings' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-600'}`}>App Settings</button>
         </div>
         
         <div className="p-8">
             {activeTab === 'verifications' && (
                 <div>
                     <h2 className="text-xl font-bold mb-4">Pending Verifications</h2>
                     <div className="space-y-4">
                         {requests.map(req => {
                             const lawyer = lawyers.find(l => l.uid === req.lawyerId);
                             return (
                                 <div key={req.id} className="border p-6 rounded-lg flex flex-col md:flex-row justify-between items-center shadow-sm">
                                     <div className="mb-4 md:mb-0">
                                         <h3 className="font-bold text-lg">{req.lawyerName}</h3>
                                         <p className="text-sm text-slate-500">Email: {req.lawyerEmail}</p>
                                         <p className="text-sm text-slate-500">Submitted: {new Date(req.submittedAt).toLocaleDateString()}</p>
                                         <div className="mt-4 p-3 bg-slate-50 rounded text-left text-sm">
                                            <p><span className="font-semibold">Degree:</span> {req.degreeName}</p>
                                            <p><span className="font-semibold">University:</span> {req.issuingAuthority}</p>
                                            <p><span className="font-semibold">License No:</span> {req.licenseNumber}</p>
                                            <p><span className="font-semibold">Enrollment/Roll No:</span> {req.enrollmentOrRollNumber}</p>
                                            <p><span className="font-semibold">Graduation Year:</span> {req.yearOfGraduation}</p>
                                            <p><span className="font-semibold">Bar Council:</span> {req.barCouncilName}</p>
                                            <p className="text-xs text-blue-600 mt-2">Guidance: Use these details to verify online via university/bar council websites.</p>
                                         </div>
                                     </div>
                                     <div className="space-x-2">
                                         <button onClick={() => handleVerify(req.id, false)} className="px-4 py-2 border border-red-500 text-red-600 rounded hover:bg-red-50">Reject</button>
                                         <button onClick={() => handleVerify(req.id, true)} className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Approve</button>
                                     </div>
                                 </div>
                             );
                         })}
                         {requests.length === 0 && <p className="text-slate-500 py-10 text-center bg-slate-50 rounded">No pending verifications.</p>}
                     </div>
                 </div>
             )}
             
             {activeTab === 'articles' && (
                 <div className="max-w-4xl mx-auto">
                     <h2 className="text-xl font-bold mb-4">{editingArticleId ? 'Edit Article' : 'Write Legal Article'} (AI Assisted)</h2>
                     <div className="bg-slate-50 p-6 rounded mb-8 border border-slate-200">
                         <div className="mb-4">
                             <label className="block text-sm font-medium mb-1">Article Title</label>
                             <div className="flex gap-2">
                                 <input className="flex-grow border p-2 rounded" value={articleTopic} onChange={e => setArticleTopic(e.target.value)} placeholder="e.g. Child Custody Laws in Pakistan" />
                                 <button onClick={handleGenerateArticle} disabled={isGenerating} className="bg-purple-600 text-white px-4 py-2 rounded whitespace-nowrap">
                                     {isGenerating ? 'Generating...' : 'Generate with AI'}
                                 </button>
                             </div>
                         </div>
                         <div className="mb-4">
                             <label className="block text-sm font-medium mb-1">Short Description</label>
                             <textarea rows={2} className="w-full border p-2 rounded" value={articleDesc} onChange={e => setArticleDesc(e.target.value)} placeholder="Brief summary of the article..." />
                         </div>
                         <div className="mb-4">
                             <label className="block text-sm font-medium mb-1">Featured Image</label>
                             <div className="flex items-center gap-4">
                                <input type="file" className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" onChange={handleImageUpload} />
                                {uploadingImage && <span className="text-sm text-blue-600">Uploading...</span>}
                                {articleImage && !uploadingImage && <img src={articleImage} alt="Featured" className="w-16 h-16 object-cover rounded" />}
                             </div>
                         </div>
                         <div className="mb-4">
                             <label className="block text-sm font-medium mb-1">Content</label>
                             <textarea className="w-full border p-2 rounded h-64" value={articleContent} onChange={e => setArticleContent(e.target.value)}></textarea>
                         </div>
                         <div className="flex gap-4">
                           <button onClick={handlePublishArticle} className="bg-slate-900 text-white px-6 py-2 rounded">
                             {editingArticleId ? 'Update Article' : 'Publish Article'}
                           </button>
                           {editingArticleId && (
                               <button onClick={handleCancelEdit} className="bg-slate-200 text-slate-700 px-6 py-2 rounded">
                                 Cancel Edit
                               </button>
                           )}
                         </div>
                     </div>

                     <h2 className="text-xl font-bold mb-4 mt-12">Published Articles</h2>
                     <div className="overflow-x-auto rounded border">
                       <table className="min-w-full text-left text-sm">
                           <thead className="bg-slate-100 uppercase font-semibold text-slate-600">
                               <tr>
                                   <th className="p-3">Title</th>
                                   <th className="p-3">Author</th>
                                   <th className="p-3">Date</th>
                                   <th className="p-3">Actions</th>
                               </tr>
                           </thead>
                           <tbody>
                               {isLoadingArticles ? (
                                   <tr><td colSpan={4} className="text-center p-4 text-slate-500">Loading articles...</td></tr>
                               ) : currentArticles.length === 0 ? (
                                   <tr><td colSpan={4} className="text-center p-4 text-slate-500">No articles published yet.</td></tr>
                               ) : (
                                   currentArticles.map(article => (
                                       <tr key={article.id} className="border-b hover:bg-slate-50 bg-white">
                                           <td className="p-3 font-medium">{article.title}</td>
                                           <td className="p-3">{article.author}</td>
                                           <td className="p-3">{article.date}</td>
                                           <td className="p-3 space-x-2">
                                               <button onClick={() => handleEditArticle(article)} className="text-blue-600 hover:underline text-sm">Edit</button>
                                               <button 
                                                    onClick={() => requestDelete(article.id, () => executeDeleteArticle(article.id))} 
                                                    disabled={deletingIds.has(article.id)}
                                                    className={`text-sm font-medium px-3 py-1 rounded transition-colors ${
                                                        confirmDeleteId === article.id 
                                                            ? 'bg-red-600 text-white hover:bg-red-700' 
                                                            : (deletingIds.has(article.id) ? 'text-slate-400 cursor-not-allowed' : 'text-red-600 hover:bg-red-50')
                                                    }`}
                                               >
                                                   {deletingIds.has(article.id) 
                                                       ? 'Deleting...' 
                                                       : (confirmDeleteId === article.id ? 'Confirm?' : 'Delete')}
                                               </button>
                                           </td>
                                       </tr>
                                   ))
                               )}
                           </tbody>
                       </table>
                     </div>
                 </div>
             )}
             
             {activeTab === 'users' && (
                 <div>
                     <h2 className="text-xl font-bold mb-4">Registered Lawyers</h2>
                     <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="bg-slate-100">
                                <tr>
                                    <th className="p-3">Name</th>
                                    <th className="p-3">Country</th>
                                    <th className="p-3">License</th>
                                    <th className="p-3">Status</th>
                                    <th className="p-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {lawyers.map(l => (
                                    <tr key={l.uid} className="border-b">
                                        <td className="p-3">{l.fullName}</td>
                                        <td className="p-3">{l.country}</td>
                                        <td className="p-3">{l.licenseNumber}</td>
                                        <td className="p-3">
                                            {l.isVerified ? <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-bold">Verified</span> : 
                                            (l.verificationStatus === 'pending' ? <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full font-bold">Pending</span> : 
                                            <span className="text-slate-500 text-sm">Unverified</span>)}
                                        </td>
                                        <td className="p-3">
                                            <button 
                                                onClick={() => requestDelete(l.uid, () => executeDeleteUser(l.uid))} 
                                                disabled={deletingIds.has(l.uid)}
                                                className={`text-sm font-medium px-3 py-1 rounded transition-colors ${
                                                    confirmDeleteId === l.uid 
                                                        ? 'bg-red-600 text-white hover:bg-red-700' 
                                                        : (deletingIds.has(l.uid) ? 'text-slate-400 cursor-not-allowed' : 'text-red-600 hover:bg-red-50')
                                                }`}
                                            >
                                                {deletingIds.has(l.uid) 
                                                    ? 'Deleting...' 
                                                    : (confirmDeleteId === l.uid ? 'Confirm?' : 'Delete Profile')}
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </div>
                 </div>
             )}

             {activeTab === 'settings' && (
                <div className="max-w-2xl mx-auto">
                    <h2 className="text-xl font-bold mb-6">App Settings</h2>

                    <div className="bg-slate-50 p-6 rounded-lg mb-8 border border-slate-200">
                        <h3 className="font-bold text-lg mb-4">Application Logo</h3>
                        <p className="text-sm text-slate-600 mb-4">Upload a custom logo for your application. This will appear in the navigation bar.</p>
                        
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2">Current Logo:</label>
                            {appLogoUrl ? (
                                <div className="p-2 border rounded-lg bg-white inline-block shadow-sm">
                                    <img src={appLogoUrl} alt="Current App Logo" className="w-24 h-auto max-h-12 object-contain" />
                                </div>
                            ) : (
                                <p className="text-slate-500 italic">No custom logo set. Using default text logo.</p>
                            )}
                        </div>

                        <div className="mb-4">
                            <label htmlFor="logoFileInput" className="block text-sm font-medium mb-1">Upload New Logo (PNG, JPG, SVG)</label>
                            <input 
                                type="file" 
                                id="logoFileInput" 
                                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" 
                                accept="image/png, image/jpeg, image/svg+xml"
                                onChange={handleLogoFileChange}
                            />
                            {logoFile && <p className="text-xs text-slate-600 mt-1">Selected: {logoFile.name}</p>}
                        </div>

                        <div className="flex gap-3 mt-5">
                            <button 
                                onClick={handleUploadLogo} 
                                disabled={uploadingLogo || !logoFile}
                                className={`bg-green-600 text-white px-5 py-2 rounded font-semibold ${uploadingLogo ? 'opacity-50 cursor-not-allowed' : 'hover:bg-green-700'}`}
                            >
                                {uploadingLogo ? 'Uploading...' : 'Upload Logo'}
                            </button>
                            <button 
                                onClick={handleRemoveLogo} 
                                disabled={uploadingLogo || !appLogoUrl}
                                className={`bg-red-600 text-white px-5 py-2 rounded font-semibold ${uploadingLogo || !appLogoUrl ? 'opacity-50 cursor-not-allowed' : 'hover:bg-red-700'}`}
                            >
                                Remove Logo
                            </button>
                        </div>
                        {logoFeedback && (
                            <p className={`mt-3 text-sm ${logoFeedback.includes('successfully') ? 'text-green-600' : 'text-red-600'}`}>{logoFeedback}</p>
                        )}
                    </div>
                </div>
             )}
         </div>
      </div>
    </div>
  );
}