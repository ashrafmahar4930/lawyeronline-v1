

export interface MetaData {
  title: string;
  description: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'profile';
  schema?: Record<string, any>;
}

export const updateMeta = (data: MetaData) => {
  // 1. Update Document Title with Branding
  document.title = `${data.title} | LawyerOnline.LIVE`;

  // 2. Update Meta Description
  let metaDesc = document.querySelector("meta[name='description']");
  if (!metaDesc) {
    metaDesc = document.createElement('meta');
    metaDesc.setAttribute('name', 'description');
    document.head.appendChild(metaDesc);
  }
  metaDesc.setAttribute('content', data.description);

  // 3. Update Open Graph (Facebook/LinkedIn)
  const ogTitle = document.querySelector("meta[property='og:title']");
  if (ogTitle) ogTitle.setAttribute('content', data.title);

  const ogDesc = document.querySelector("meta[property='og:description']");
  if (ogDesc) ogDesc.setAttribute('content', data.description);

  const ogUrl = document.querySelector("meta[property='og:url']");
  if (ogUrl && data.url) ogUrl.setAttribute('content', data.url);

  const ogImage = document.querySelector("meta[property='og:image']");
  if (ogImage && data.image) ogImage.setAttribute('content', data.image);

  // 4. Inject JSON-LD Schema (Structured Data)
  if (data.schema) {
    let scriptTag = document.querySelector("script[type='application/ld+json']");
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.setAttribute('type', 'application/ld+json');
      document.head.appendChild(scriptTag);
    }
    
    // SAFE JSON STRINGIFY: Prevents "circular structure" crashes
    try {
        scriptTag.textContent = JSON.stringify(data.schema);
    } catch (e) {
        console.warn("Skipping SEO Schema due to circular reference:", e);
        scriptTag.textContent = ""; // Clear content if error occurs
    }
  }
};

export const defaultSchema = {
  "@context": "https://schema.org",
  "@type": "LegalService",
  "name": "LawyerOnline.LIVE",
  "url": "https://www.lawyeronline.live",
  "logo": "https://firebasestorage.googleapis.com/v0/b/jurisconnect-wwep2.firebasestorage.app/o/app-settings%2Flogo%2Fapp_logo.png?alt=media",
  "description": "Connect with verified top-tier advocates, barristers, and legal consultants worldwide. AI-powered legal drafting and case management.",
  "sameAs": [
    "https://www.facebook.com/lawyeronline.live",
    "https://twitter.com/lawyeronline"
  ],
  "address": {
    "@type": "PostalAddress",
    "addressCountry": "Global"
  }
};