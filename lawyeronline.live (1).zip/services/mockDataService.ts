

import { LawyerProfile, Case, KhataEntry, VerificationRequest, Article, ImportantDate, CaseFile, Country, Review, Favorite, ConsultationLog, Booking } from '../types';
import { db, storage } from './firebase';
import { 
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, query, where, Timestamp, orderBy, limit, onSnapshot 
} from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';

// Base64 encoded SVG for a simple 'L' logo as a robust fallback
export const DEFAULT_LOGO_SVG = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjI0IiBoZWlnaHQ9IjI0IiByeD0iNCIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTEwIDdWMjhoNlY3SDEwWiIgZmlsbD0iIzAyMjY0NCIvPgo8L3N2Zz4K";

// --- Storage Helpers ---

export const deleteFile = async (fileUrl: string) => {
  if (!fileUrl || !fileUrl.includes('firebasestorage.googleapis.com')) {
    // console.warn("Attempted to delete a non-Firebase Storage URL or empty URL:", fileUrl);
    return;
  }
  try {
    // Extract path from the full download URL
    const url = new URL(fileUrl);
    // Path typically looks like /o/folder%2Ffilename.ext?altMedia...
    // We need to decode the path segments and ignore query params
    const pathSegments = url.pathname.split('/o/')[1].split('?')[0];
    const path = decodeURIComponent(pathSegments);
    
    const fileRef = storageRef(storage as any, path);
    await deleteObject(fileRef);
    console.log("Old file deleted:", fileUrl);
  } catch (error) {
    console.error("Error deleting old file:", error);
    // Don't throw, as the new upload should still proceed even if old file deletion fails.
  }
};


export const uploadFile = async (file: File, path: string, oldFileUrl?: string): Promise<string> => {
  try {
    if (oldFileUrl) {
      await deleteFile(oldFileUrl);
    }
    const sRef = storageRef(storage as any, path);
    const snapshot = await uploadBytes(sRef, file);
    return await getDownloadURL(snapshot.ref);
  } catch (error) {
    console.error("Upload failed", error);
    throw error;
  }
};

// --- Helpers to Map DB Schema to App Schema ---

const mapToAppProfile = (data: any, uid: string): LawyerProfile => {
  return {
    uid: uid,
    fullName: data.name || '',
    title: data.title || 'Advocate',
    specialties: data.specialties || [], 
    country: data.country || '',
    city: data.city || '',
    officeName: data.officeName || '',
    officeAddress: data.officeAddress || '',
    contactMobile: data.phone || '',
    contactWhatsapp: data.whatsapp || '',
    contactEmail: data.email || '',
    socialMediaLink: data.facebookUrl || data.linkedinUrl || '',
    degreeName: data.education?.[0] || '',
    issuingAuthority: data.licenseIssuingAuthority || '',
    licenseNumber: data.licenseNumber || '',
    aboutMe: data.about || '',
    achievements: data.achievements || '',
    isVerified: data.isVerified || false,
    verificationStatus: data.verificationStatus || (data.isVerified ? 'approved' : 'none'),
    rejectionReason: data.rejectionReason,
    // SANITIZATION: Ensure picture is a string or undefined. Objects here cause circular JSON errors.
    picture: typeof data.picture === 'string' ? data.picture : undefined,
    rating: data.rating !== undefined ? data.rating : 0, 
    reviewCount: data.reviewCount !== undefined ? data.reviewCount : 0, 
    // New textual verification fields
    enrollmentOrRollNumber: data.enrollmentOrRollNumber || '',
    yearOfGraduation: data.yearOfGraduation || '',
    barCouncilName: data.barCouncilName || '',
  };
};

const mapToDbProfile = (profile: LawyerProfile) => {
    return {
        name: profile.fullName,
        title: profile.title,
        specialties: profile.specialties, 
        country: profile.country,
        city: profile.city,
        officeName: profile.officeName,
        officeAddress: profile.officeAddress,
        phone: profile.contactMobile,
        whatsapp: profile.contactWhatsapp,
        email: profile.contactEmail,
        facebookUrl: profile.socialMediaLink, 
        education: profile.degreeName ? [profile.degreeName] : [],
        licenseIssuingAuthority: profile.issuingAuthority,
        licenseNumber: profile.licenseNumber,
        about: profile.aboutMe,
        achievements: profile.achievements,
        isVerified: profile.isVerified,
        verificationStatus: profile.verificationStatus,
        rejectionReason: profile.rejectionReason || null,
        picture: profile.picture || null,
        userId: profile.uid,
        id: profile.uid, 
        updatedAt: new Date().toISOString(),
        enrollmentOrRollNumber: profile.enrollmentOrRollNumber || '',
        yearOfGraduation: profile.yearOfGraduation || '',
        barCouncilName: profile.barCouncilName || '',
    };
};

const mapToAppArticle = (data: any, id: string): Article => {
    let dateStr = 'Recently';
    if (data.createdAt) {
        if (data.createdAt.toDate) {
            dateStr = data.createdAt.toDate().toLocaleDateString();
        } else if (typeof data.createdAt === 'string') {
            dateStr = new Date(data.createdAt).toLocaleDateString();
        }
    }
    
    return {
        id: id,
        title: data.title || 'Untitled',
        content: data.content || '',
        description: data.description || '',
        author: data.author || 'Admin',
        date: dateStr,
        // SANITIZATION: Ensure featuredImage is a string or undefined.
        featuredImage: typeof data.featuredImage === 'string' ? data.featuredImage : undefined,
        slug: data.slug || id 
    };
};

const mapToDbArticle = (article: Article) => {
    return {
        title: article.title,
        content: article.content,
        description: article.description,
        author: article.author,
        featuredImage: article.featuredImage || null,
        slug: article.slug,
        createdAt: new Date(), 
        updatedAt: new Date()
    };
}

const mapToAppCase = (data: any, id: string): Case => {
    return {
        id: id,
        lawyerId: data.lawyerId || '',
        clientName: data.clientName || '',
        caseTitle: data.caseTitle || '',
        courtName: data.courtName || '',
        nextHearingDate: data.nextHearingDate || '',
        stage: data.stage || 'Filing',
        notes: data.notes || '',
        description: data.description || '',
        opposingCounsel: data.opposingCounsel || '',
        status: data.status || 'Open',
        importantDates: data.importantDates || [],
        caseFiles: data.caseFiles || [],
    };
};

const mapToDbCase = (c: Case) => {
    return {
        id: c.id,
        lawyerId: c.lawyerId,
        clientName: c.clientName,
        caseTitle: c.caseTitle,
        courtName: c.courtName,
        nextHearingDate: c.nextHearingDate,
        stage: c.stage,
        notes: c.notes,
        description: c.description || '',
        opposingCounsel: c.opposingCounsel || '',
        status: c.status || 'Open',
        importantDates: c.importantDates || [],
        caseFiles: c.caseFiles || [],
        updatedAt: new Date().toISOString(),
        createdAt: c.id.startsWith('case_') ? new Date(parseInt(c.id.substring(5))).toISOString() : new Date().toISOString()
    };
};


// --- User & Profile (Lawyers Collection) ---

export const getLawyerProfile = async (uid: string): Promise<LawyerProfile | undefined> => {
  try {
    const docRef = doc(db, 'lawyers', uid);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return mapToAppProfile(docSnap.data(), uid);
    }
    return undefined;
  } catch (error) {
    console.error("Error fetching profile:", error);
    return undefined;
  }
};

export const updateLawyerProfile = async (profile: LawyerProfile) => {
  try {
    const oldProfile = await getLawyerProfile(profile.uid);
    let updatedProfile = { ...profile };
    
    if (oldProfile) {
        const areArraysEqual = (a: string[], b: string[]) => {
            if (a.length !== b.length) return false;
            const sortedA = [...a].sort();
            const sortedB = [...b].sort();
            return sortedA.every((val, index) => val === sortedB[index]);
        };

        const changedCriticalInfo = 
            oldProfile.fullName !== profile.fullName || 
            oldProfile.title !== profile.title || 
            !areArraysEqual(oldProfile.specialties, profile.specialties) || 
            oldProfile.country !== profile.country ||
            oldProfile.city !== profile.city ||
            oldProfile.officeName !== profile.officeName ||
            oldProfile.officeAddress !== profile.officeAddress ||
            oldProfile.contactMobile !== profile.contactMobile ||
            oldProfile.contactWhatsapp !== profile.contactWhatsapp ||
            oldProfile.socialMediaLink !== profile.socialMediaLink ||
            oldProfile.degreeName !== profile.degreeName ||
            oldProfile.issuingAuthority !== profile.issuingAuthority ||
            oldProfile.licenseNumber !== profile.licenseNumber ||
            oldProfile.aboutMe !== profile.aboutMe ||
            oldProfile.achievements !== profile.achievements ||
            oldProfile.enrollmentOrRollNumber !== profile.enrollmentOrRollNumber ||
            oldProfile.yearOfGraduation !== profile.yearOfGraduation ||
            oldProfile.barCouncilName !== profile.barCouncilName;


        if (changedCriticalInfo) {
            if (oldProfile.isVerified) {
                updatedProfile.isVerified = false;
                updatedProfile.verificationStatus = 'none'; 
                updatedProfile.rejectionReason = "Profile information changed, re-verification required.";
            }
        }
    }

    const dbData: any = mapToDbProfile(updatedProfile);
    if (profile.rating === undefined) delete dbData.rating; // @ts-ignore
    if (profile.reviewCount === undefined) delete dbData.reviewCount; // @ts-ignore

    await setDoc(doc(db, 'lawyers', profile.uid), dbData, { merge: true });
  } catch (error) {
    console.error("Error updating profile:", error);
    throw error;
  }
};

export const getAllLawyers = async (): Promise<LawyerProfile[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, 'lawyers'));
    const profiles: LawyerProfile[] = [];
    querySnapshot.forEach((doc) => {
      profiles.push(mapToAppProfile(doc.data(), doc.id));
    });
    return profiles;
  } catch (error) {
    console.error("Error getting lawyers:", error);
    return [];
  }
};

export const deleteLawyerProfile = async (uid: string) => {
  console.log(`Starting deletion process for lawyer UID: ${uid}`);

  try {
    try {
        const lawyerProfile = await getLawyerProfile(uid);
        if (lawyerProfile?.picture) {
            console.log(`Deleting profile picture: ${lawyerProfile.picture}`);
            await deleteFile(lawyerProfile.picture);
        }
    } catch (e) {
        console.warn("Failed to delete profile picture (continuing...):", e);
    }

    try {
        console.log(`Fetching cases for lawyer: ${uid}`);
        const lawyerCases = await getLawyerCases(uid);
        for (const c of lawyerCases) {
            console.log(`Deleting case and its associated data for caseId: ${c.id}`);
            await deleteCase(c.id); 
        }
    } catch (e) {
        console.error(`Error deleting cases for lawyer ${uid}. Possible permission issue?`, e);
        throw new Error("Failed to delete associated cases. Check 'Cases' collection permissions.");
    }

    try {
        console.log(`Deleting lawyer profile document from 'lawyers' collection for UID: ${uid}`);
        await deleteDoc(doc(db, 'lawyers', uid));
    } catch (e) {
        console.error(`Error deleting lawyer profile ${uid}.`, e);
        throw new Error("Failed to delete Lawyer Profile document. Check 'Lawyers' collection permissions.");
    }

    try {
        console.log(`Deleting user document from 'users' collection for UID: ${uid}`);
        await deleteDoc(doc(db, 'users', uid));
    } catch (e) {
        console.error(`Error deleting user document ${uid}.`, e);
        throw new Error("Failed to delete User Role document. Check 'Users' collection permissions.");
    }
    
    try {
        const qFav = query(collection(db, 'favorites'), where('lawyerId', '==', uid));
        const qCon = query(collection(db, 'consultations'), where('lawyerId', '==', uid));
        const qRev = query(collection(db, 'reviews'), where('lawyerId', '==', uid));
        const qBook = query(collection(db, 'bookings'), where('lawyerId', '==', uid));
        
        const [favSnap, conSnap, revSnap, bookSnap] = await Promise.all([
            getDocs(qFav), getDocs(qCon), getDocs(qRev), getDocs(qBook)
        ]);

        await Promise.all([
            ...favSnap.docs.map(d => deleteDoc(d.ref)),
            ...conSnap.docs.map(d => deleteDoc(d.ref)),
            ...revSnap.docs.map(d => deleteDoc(d.ref)),
            ...bookSnap.docs.map(d => deleteDoc(d.ref))
        ]);
    } catch (e) {
        console.warn("Failed to clean up associated data (reviews/favorites) - continuing:", e);
    }

    console.log(`Deletion process for lawyer UID ${uid} completed successfully.`);

  } catch (error: any) {
    console.error(`Deletion process halted for UID ${uid}:`, error);
    throw error;
  }
};

// --- Bookings (Appointments) ---

export const addBooking = async (booking: Booking) => {
    try {
        await setDoc(doc(db, 'bookings', booking.id), booking);
    } catch (error) {
        console.error("Error adding booking:", error);
        throw error;
    }
};

export const getBookingsForLawyer = async (lawyerId: string): Promise<Booking[]> => {
    try {
        const q = query(collection(db, 'bookings'), where('lawyerId', '==', lawyerId), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        const bookings: Booking[] = [];
        querySnapshot.forEach(doc => bookings.push(doc.data() as Booking));
        return bookings;
    } catch (error) {
        console.warn("Error fetching bookings for lawyer:", error);
        return [];
    }
};

export const getBookingsForClient = async (clientId: string): Promise<Booking[]> => {
    try {
        const q = query(collection(db, 'bookings'), where('clientId', '==', clientId), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        const bookings: Booking[] = [];
        querySnapshot.forEach(doc => bookings.push(doc.data() as Booking));
        return bookings;
    } catch (error) {
        console.warn("Error fetching bookings for client:", error);
        return [];
    }
};

export const updateBookingStatus = async (bookingId: string, status: 'confirmed' | 'rejected') => {
    try {
        await updateDoc(doc(db, 'bookings', bookingId), { status });
    } catch (error) {
        console.error("Error updating booking status:", error);
        throw error;
    }
};

// --- Reviews ---

export const addReview = async (review: Review) => {
    try {
        const reviewRef = doc(db, 'reviews', review.id);
        await setDoc(reviewRef, review);

        const lawyerRef = doc(db, 'lawyers', review.lawyerId);
        const lawyerSnap = await getDoc(lawyerRef);
        
        if (lawyerSnap.exists()) {
            const data = lawyerSnap.data();
            const currentRating = data.rating || 0;
            const currentCount = data.reviewCount || 0;

            const newCount = currentCount + 1;
            const newRating = ((currentRating * currentCount) + review.rating) / newCount;
            
            const roundedRating = Math.round(newRating * 10) / 10;

            await updateDoc(lawyerRef, {
                rating: roundedRating,
                reviewCount: newCount
            });
        }
    } catch (error) {
        console.error("Error adding review:", error);
        throw error;
    }
};

export const getReviews = async (lawyerId: string): Promise<Review[]> => {
    try {
        const q = query(collection(db, 'reviews'), where('lawyerId', '==', lawyerId));
        const querySnapshot = await getDocs(q);
        const reviews: Review[] = [];
        querySnapshot.forEach((doc) => {
            reviews.push(doc.data() as Review);
        });
        return reviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (error) {
        console.warn("Error getting reviews:", error);
        return [];
    }
};

// --- Cases ---

export const getLawyerCases = async (lawyerId: string): Promise<Case[]> => {
  try {
    const q = query(collection(db, 'cases'), where('lawyerId', '==', lawyerId));
    const querySnapshot = await getDocs(q);
    const cases: Case[] = [];
    querySnapshot.forEach((doc) => {
      cases.push(mapToAppCase(doc.data(), doc.id));
    });
    return cases;
  } catch (error) {
    console.warn("Error getting cases (might be empty):", error);
    return [];
  }
};

export const addCase = async (newCase: Case) => {
  try {
    await setDoc(doc(db, 'cases', newCase.id), mapToDbCase(newCase));
  } catch (error) {
    console.error("Error adding case:", error);
    throw error;
  }
};

export const updateCase = async (updatedCase: Case) => {
    try {
        await updateDoc(doc(db, 'cases', updatedCase.id), mapToDbCase(updatedCase));
    } catch (error) {
        console.error("Error updating case:", error);
        throw error;
    }
};

export const deleteCase = async (caseId: string) => {
    try {
        console.log(`Starting deletion of case: ${caseId}`);
        const caseRef = doc(db, 'cases', caseId);
        const caseSnap = await getDoc(caseRef);

        if (caseSnap.exists()) {
            const caseData = mapToAppCase(caseSnap.data(), caseId);
            if (caseData.caseFiles && caseData.caseFiles.length > 0) {
                for (const file of caseData.caseFiles) {
                    console.log(`Deleting case file: ${file.name}`);
                    await deleteFile(file.url);
                }
            }
        }
        
        console.log(`Deleting khata entries for case: ${caseId}`);
        const qKhata = query(collection(db, 'khata'), where('caseId', '==', caseId));
        const khataSnap = await getDocs(qKhata);
        const deleteKhataPromises = khataSnap.docs.map(d => deleteDoc(d.ref));
        await Promise.all(deleteKhataPromises);

        console.log(`Deleting case document: ${caseId}`);
        await deleteDoc(caseRef);
        console.log(`Deletion of case ${caseId} completed.`);
    } catch (error) {
        console.error(`Error deleting case ${caseId}:`, error);
        throw error;
    }
};

// --- Khata ---

export const getCaseKhata = async (caseId: string): Promise<KhataEntry[]> => {
    try {
      const q = query(collection(db, 'khata'), where('caseId', '==', caseId));
      const querySnapshot = await getDocs(q);
      const khata: KhataEntry[] = [];
      querySnapshot.forEach((doc) => {
        khata.push(doc.data() as KhataEntry);
      });
      return khata;
    } catch (error) {
      console.warn("Error getting khata:", error);
      return [];
    }
}

export const addKhataEntry = async (entry: KhataEntry) => {
    try {
      await setDoc(doc(db, 'khata', entry.id), entry);
    } catch (error) {
      console.error("Error adding khata:", error);
      throw error;
    }
}

export const deleteKhataEntry = async (entryId: string) => {
    try {
        await deleteDoc(doc(db, 'khata', entryId));
    } catch (error) {
        console.error("Error deleting khata entry:", error);
        throw error;
    }
};

// --- Verification ---

export const submitVerification = async (req: VerificationRequest) => {
    try {
      await setDoc(doc(db, 'verifications', req.id), req);
    } catch (error) {
      console.error("Error submitting verification:", error);
      throw error;
    }
}

export const getPendingVerifications = async (): Promise<VerificationRequest[]> => {
    try {
      const q = query(collection(db, 'verifications'), where('status', '==', 'pending'));
      const querySnapshot = await getDocs(q);
      const reqs: VerificationRequest[] = [];
      querySnapshot.forEach((doc) => {
        reqs.push(doc.data() as VerificationRequest);
      });
      return reqs;
    } catch (error) {
      console.warn("Error getting verifications:", error);
      return [];
    }
}

export const processVerification = async (id: string, status: 'approved' | 'rejected', reason?: string) => {
    try {
        const reqRef = doc(db, 'verifications', id);
        const reqSnap = await getDoc(reqRef);
        
        if (reqSnap.exists()) {
            const reqData = reqSnap.data() as VerificationRequest;
            await updateDoc(reqRef, { status });

            const profileRef = doc(db, 'lawyers', reqData.lawyerId);
            const updates: any = {
                verificationStatus: status,
                isVerified: status === 'approved'
            };
            if (status === 'rejected' && reason) {
                updates.rejectionReason = reason;
            } else if (status === 'approved') {
                updates.rejectionReason = null; 
            }
            await updateDoc(profileRef, updates);
        }
    } catch (error) {
        console.error("Error processing verification:", error);
        throw error;
    }
}

// --- Articles ---

const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') 
    .replace(/[\s_-]+/g, '-') 
    .replace(/^-+|-+$/g, ''); 
};


export const addArticle = async (article: Article) => {
    try {
        const dbArticle = {
            title: article.title,
            content: article.content,
            description: article.description,
            author: article.author,
            featuredImage: article.featuredImage || null,
            slug: generateSlug(article.title), 
            createdAt: new Date(),
            updatedAt: new Date()
        };
        await setDoc(doc(db, 'articles', article.id), dbArticle);
    } catch (error) {
        console.error("Error adding article:", error);
        throw error;
    }
}

export const updateArticle = async (article: Article) => {
    try {
        const dbArticle = {
            title: article.title,
            content: article.content,
            description: article.description,
            author: article.author, 
            featuredImage: article.featuredImage || null,
            slug: generateSlug(article.title), 
            updatedAt: new Date()
        };
        await updateDoc(doc(db, 'articles', article.id), dbArticle);
    } catch (error) {
        console.error("Error updating article:", error);
        throw error;
    }
}

export const deleteArticle = async (articleId: string) => {
    try {
        console.log(`Starting deletion of article: ${articleId}`);
        const articleRef = doc(db, 'articles', articleId);
        const articleSnap = await getDoc(articleRef);

        if (articleSnap.exists()) {
            const articleData = mapToAppArticle(articleSnap.data(), articleId);
            if (articleData.featuredImage) {
                console.log(`Deleting featured image for article: ${articleId}`);
                await deleteFile(articleData.featuredImage);
            }
        }
        await deleteDoc(articleRef);
        console.log(`Deletion of article ${articleId} completed.`);
    } catch (error) {
        console.error(`Error deleting article ${articleId}:`, error);
        throw error;
    }
}


export const getArticles = async (): Promise<Article[]> => {
    try {
        const querySnapshot = await getDocs(collection(db, 'articles'));
        const articles: Article[] = [];
        querySnapshot.forEach((doc) => {
            articles.push(mapToAppArticle(doc.data(), doc.id));
        });
        return articles;
    } catch (error) {
        console.warn("Error getting articles:", error);
        return [];
    }
}

export const getArticleBySlug = async (slug: string): Promise<Article | null> => {
    try {
        const q = query(collection(db, 'articles'), where('slug', '==', slug), limit(1));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
            const doc = querySnapshot.docs[0];
            return mapToAppArticle(doc.data(), doc.id);
        }
        return null;
    } catch (error) {
        console.warn("Error getting article by slug:", error);
        return null;
    }
}

// Helper for Auth
export const getUserRole = async (uid: string): Promise<string | null> => {
    try {
        const docRef = doc(db, 'users', uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            return docSnap.data().role;
        }
        
        const lawyerRef = doc(db, 'lawyers', uid);
        const lawyerSnap = await getDoc(lawyerRef);
        if (lawyerSnap.exists()) {
            return 'lawyer';
        }

        return null;
    } catch (error) {
        console.warn("Error getting user role:", error);
        return null;
    }
}

export const setUserRole = async (uid: string, role: string, email: string) => {
    try {
        await setDoc(doc(db, 'users', uid), { role, email });
        
        if (role === 'lawyer' || role === 'admin') {
             const lawyerRef = doc(db, 'lawyers', uid);
             const snap = await getDoc(lawyerRef);
             if (!snap.exists()) {
                 await setDoc(lawyerRef, {
                     id: uid,
                     userId: uid,
                     email: email,
                     createdAt: new Date().toISOString(),
                     isVerified: false,
                     isSuspended: false,
                     rating: 0, 
                     reviewCount: 0,
                     name: email.split('@')[0], 
                     country: 'Pakistan', 
                     verificationStatus: 'none',
                     fullName: email.split('@')[0], 
                     title: 'Advocate',
                     specialties: ['General'], 
                     city: '',
                     officeName: '',
                     officeAddress: '',
                     contactMobile: '',
                     contactWhatsapp: '',
                     socialMediaLink: '',
                     degreeName: '',
                     issuingAuthority: '',
                     licenseNumber: '',
                     aboutMe: '',
                     achievements: '',
                     picture: null,
                     enrollmentOrRollNumber: '',
                     yearOfGraduation: '',
                     barCouncilName: '',
                 });
             }
        }
    } catch (error) {
        console.error("Error setting role:", error);
    }
}

// --- App Settings (e.g., Logo) ---

const APP_LOGO_DOC_REF = doc(db, 'settings', 'app_logo');
const APP_LOGO_STORAGE_PATH = 'app-settings/logo/app_logo.png'; 

export const getAppLogoUrl = async (): Promise<string | null> => {
  try {
    const docSnap = await getDoc(APP_LOGO_DOC_REF);
    if (docSnap.exists()) {
      return docSnap.data().url || null;
    }
    return null;
  } catch (error) {
    return null;
  }
};

export const subscribeToAppLogo = (callback: (url: string | null) => void) => {
    return onSnapshot(APP_LOGO_DOC_REF, (doc) => {
        if (doc.exists()) {
            callback(doc.data().url || null);
        } else {
            callback(null);
        }
    }, (error) => {
        console.warn("Error subscribing to app logo:", error);
        callback(null); 
    });
};

export const updateAppLogo = async (file: File, oldUrl?: string): Promise<string> => {
  try {
    if (oldUrl) {
      await deleteFile(oldUrl); 
    }
    const sRef = storageRef(storage as any, APP_LOGO_STORAGE_PATH);
    const snapshot = await uploadBytes(sRef, file);
    const newUrl = await getDownloadURL(snapshot.ref);
    
    await setDoc(APP_LOGO_DOC_REF, { url: newUrl }); 
    return newUrl;
  } catch (error) {
    console.error("Error updating app logo:", error);
    throw error;
  }
};

export const deleteAppLogo = async (url: string) => {
  try {
    await deleteFile(url); 
    await updateDoc(APP_LOGO_DOC_REF, { url: null }); 
  } catch (error) {
    console.error("Error deleting app logo:", error);
    throw error;
  }
};


// --- Mock Data Helpers for Dropdowns ---

export const getCountries = async (): Promise<Country[]> => {
    return [
        { name: "Pakistan", code: "pk", cities: ["Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta", "Sialkot", "Gujranwala", "Abbottabad", "Bahawalpur", "Sargodha", "Sukkur", "Larkana", "Sheikhupura", "Jhang", "Rahim Yar Khan", "Gujrat", "Mardan", "Kasur", "Dera Ghazi Khan", "Sahiwal", "Nawabshah", "Mingora", "Okara", "Mirpur Khas", "Chiniot", "Kamoke", "Mandi Bahauddin"] },
        { name: "India", code: "in", cities: ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Surat", "Lucknow", "Kanpur", "Nagpur", "Indore", "Thane", "Bhopal", "Visakhapatnam", "Pimpri-Chinchwad", "Patna", "Vadodara", "Ghaziabad", "Ludhiana", "Agra", "Nashik", "Ranchi", "Faridabad", "Meerut", "Rajkot", "Kalyan-Dombivli", "Vasai-Virar"] },
        { name: "United States", code: "us", cities: ["New York", "Nawa", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Jacksonville", "Fort Worth", "Columbus", "San Francisco", "Charlotte", "Indianapolis", "Seattle", "Denver", "Washington D.C.", "Boston", "El Paso", "Nashville", "Detroit", "Oklahoma City", "Portland", "Las Vegas", "Memphis", "Louisville", "Baltimore"] },
        { name: "United Kingdom", code: "gb", cities: ["London", "Manchester", "Birmingham", "Leeds", "Glasgow", "Liverpool", "Newcastle", "Nottingham", "Sheffield", "Bristol", "Belfast", "Leicester", "Edinburgh", "Southampton", "Cardiff", "Coventry", "Bradford", "Hull", "Stoke-onTrent", "Wolverhampton", "Plymouth", "Derby", "Reading", "Sunderland", "Brighton", "Luton", "Portsmouth", "Bolton", "Preston", "Norwich"] },
        { name: "Canada", code: "ca", cities: ["Toronto", "Vancouver", "Montreal", "Calgary", "Ottawa", "Edmonton", "Mississauga", "Winnipeg", "Hamilton", "Quebec City", "Kitchener", "London", "Victoria", "Halifax", "Oshawa", "Windsor", "Saskatoon", "Regina", "St. John's", "Kelowna", "Barrie", "Sherbrooke", "Guelph", "Kanata", "Abbotsford", "Trois-Rivières", "Kingston", "Milton", "Moncton", "White Rock"] },
        { name: "Australia", code: "au", cities: ["Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Canberra", "Newcastle", "Wollongong", "Hobart", "Geelong", "Townsville", "Cairns", "Darwin", "Toowoomba", "Ballarat", "Bendigo", "Albury", "Launceston", "Mackay", "Rockhampton", "Bunbury", "Bundaberg", "Wagga Wagga", "Hervey Bay", "Mildura", "Wentworth", "Shepparton", "Gladstone", "Tamworth"] },
        { name: "United Arab Emirates", code: "ae", cities: ["Dubai", "Abu Dhabi", "Sharjah", "Al Ain", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain", "Khor Fakkan", "Kalba", "Jebel Ali", "Dibba Al-Fujairah", "Madinat Zayed", "Ruwais", "Liwa Oasis", "Dhaid", "Ghayathi", "Ar-Rams", "Dibba Al-Hisn", "Hatta"] },
        { name: "Saudi Arabia", code: "sa", cities: ["Riyadh", "Jeddah", "Mecca", "Medina", "Dammam", "Taif", "Tabuk", "Buraydah", "Khobar", "Abha", "Khamis Mushait", "Hail", "Najran", "Yanbu", "Al Jubail", "Al Hofuf", "Al Qatif", "Al Mubarraz", "Al Kharj", "Arar", "Sakaka", "Jizan", "Al Qurayyat", "Dhahran", "Al Bahah", "Tarut", "Bishah", "Al Rass", "Al Shafa", "Sayhat"] },
        { name: "Qatar", code: "qa", cities: ["Doha", "Al Rayyan", "Al Wakrah", "Al Khor", "Umm Salal", "Al Daayen", "Madinat ash Shamal", "Al Shahaniya", "Mesaieed", "Dukhan", "Lusail", "The Pearl-Qatar", "West Bay"] },
        { name: "Germany", code: "de", cities: ["Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Dortmund", "Essen", "Leipzig", "Bremen", "Dresden", "Hanover", "Nuremberg", "Duisburg", "Bochum", "Wuppertal", "Bielefeld", "Bonn", "Münster", "Karlsruhe", "Mannheim", "Augsburg", "Wiesbaden", "Gelsenkirchen", "Mönchengladbach", "Braunschweig", "Chemnitz", "Kiel", "Aachen"] },
        { name: "France", code: "fr", cities: ["Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier", "Bordeaux", "Lille", "Rennes", "Reims", "Le Havre", "Saint-Étienne", "Toulon", "Grenoble", "Dijon", "Nîmes", "Angers", "Villeurbanne", "Le Mans", "Saint-Denis", "Aix-en-Provence", "Clermont-Ferrand", "Brest", "Limoges", "Tours", "Amiens", "Perpignan", "Metz"] },
        { name: "Italy", code: "it", cities: ["Rome", "Milan", "Naples", "Turin", "Palermo", "Genoa", "Bologna", "Florence", "Bari", "Catania", "Venice", "Verona", "Messina", "Padua", "Trieste", "Taranto", "Brescia", "Parma", "Prato", "Modena", "Reggio Calabria", "Reggio Emilia", "Perugia", "Livorno", "Ravenna", "Cagliari", "Foggia", "Rimini", "Salerno", "Ferrara"] },
        { name: "Spain", code: "es", cities: ["Madrid", "Barcelona", "Valencia", "Seville", "Zaragoza", "Málaga", "Murcia", "Palma", "Las Palmas", "Bilbao", "Alicante", "Córdoba", "Valladolid", "Vigo", "Gijón", "L'Hospitalet de Llobregat", "A Coruña", "Vitoria-Gasteiz", "Granada", "Elche", "Oviedo", "Badalona", "Cartagena", "Terrassa", "Jerez de la Frontera", "Sabadell", "Santa Cruz de Tenerife", "Pamplona", "Almería", "Fuenlabrada"] },
        { name: "China", code: "cn", cities: ["Shanghai", "Beijing", "Guangzhou", "Shenzhen", "Chengdu", "Tianjin", "Wuhan", "Dongguan", "Chongqing", "Xi'an", "Hangzhou", "Foshan", "Nanjing", "Shenyang", "Zhengzhou", "Qingdao", "Suzhou", "Jinan", "Harbin", "Changsha", "Kunming", "Changchun", "Hefei", "Dalian", "Taiyuan", "Nanning", "Ningbo", "Fuzhou", "Xiamen", "Wenzhou"] },
        { name: "Japan", code: "jp", cities: ["Tokyo", "Yokohama", "Osaka", "Nagoya", "Sapporo", "Fukuoka", "Kobe", "Kyoto", "Kawasaki", "Saitama", "Hiroshima", "Sendai", "Chiba", "Kitakyushu", "Sakai", "Niigata", "Hamamatsu", "Kumamoto", "Sagamihara", "Shizuoka", "Okayama", "Kagoshima", "Hachioji", "Himeji", "Matsuyama", "Utsunomiya", "Higashiosaka", "Kawaguchi", "Matsudo", "Nishinomiya"] },
        { name: "Turkey", code: "tr", cities: ["Istanbul", "Ankara", "Izmir", "Bursa", "Adana", "Gaziantep", "Antalya", "Konya", "Kayseri", "Mersin", "Eskisehir", "Diyarbakir", "Samsun", "Denizli", "Sanliurfa", "Adapazari", "Malatya", "Kahramanmaras", "Erzurum", "Van", "Batman", "Elazig", "Izmit", "Manisa", "Sivas", "Gebze", "Balikesir", "Tarsus", "Kütahya", "Trabzon"] },
        { name: "Malaysia", code: "my", cities: ["Kuala Lumpur", "George Town", "Johor Bahru", "Ipoh", "Shah Alam", "Petaling Jaya", "Malacca City", "Kota Kinabalu", "Kuantan", "Alor Setar", "Tawau", "Sandakan", "Kuala Terengganu", "Kuching", "Kota Bharu", "Miri", "Seremban", "Subang Jaya", "Klang", "Selayang", "Ampang Jaya", "Kajang", "Taiping", "Sibu", "Bintulu", "Pasir Gudang", "Sungai Petani", "Kluang", "Batu Pahat", "Muar"] },
        { name: "Indonesia", code: "id", cities: ["Jakarta", "Surabaya", "Bandung", "Medan", "Semarang", "Palembang", "Makassar", "Batam", "Pekanbaru", "Bogor", "Bandar Lampung", "Padang", "Denpasar", "Malang", "Samarinda", "Tasikmalaya", "Banjarmasin", "Balikpapan", "Serang", "Jambi", "Pontianak", "Cimahi", "Manado", "Kupang", "Jayapura", "Mataram", "Yogyakarta", "Cirebon", "Sukabumi", "Bengkulu"] },
        { name: "Brazil", code: "br", cities: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador", "Fortaleza", "Belo Horizonte", "Manaus", "Curitiba", "Recife", "Porto Alegre", "Belém", "Goiânia", "Guarulhos", "Campinas", "São Luís", "São Gonçalo", "Maceió", "Duque de Caxias", "Natal", "Campo Grande", "Teresina", "São Bernardo do Campo", "Nova Iguaçu", "João Pessoa", "Santo André", "Osasco", "Jaboatão dos Guararapes", "Ribeirão Preto", "Uberlândia", "Contagem"] },
        { name: "Russia", code: "ru", cities: ["Moscow", "Saint Petersburg", "Novosibirsk", "Yekaterinburg", "Kazan", "Nizhny Novgorod", "Chelyabinsk", "Samara", "Omsk", "Rostov-on-Don", "Ufa", "Krasnoyarsk", "Voronezh", "Perm", "Volgograd", "Krasnodar", "Saratov", "Tyumen", "Tolyatti", "Izhevsk", "Barnaul", "Ulyanovsk", "Irkutsk", "Khabarovsk", "Yaroslavl", "Vladivostok", "Makhachkala", "Tomsk", "Orenburg", "Kemerovo"] },
        { name: "South Africa", code: "za", cities: ["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth", "Bloemfontein", "East London", "Polokwane", "Nelspruit", "Kimberley", "Pietermaritzburg", "Vereeniging", "Welkom", "Newcastle", "Rustenburg", "Klerksdorp", "George", "Witbank", "Potchefstroom", "Paarl", "Uitenhage", "Stellenbosch", "Worcester", "Grahamstown", "Upington", "Mthatha", "Queenstown", "Kroonstad", "Bethal", "Britz"] },
        { name: "Egypt", code: "eg", cities: ["Cairo", "Alexandria", "Giza", "Shubra El Kheima", "Port Said", "Suez", "Luxor", "Mansoura", "El Mahalla El Kubra", "Tanta", "Asyut", "Ismailia", "Faiyum", "Zagazig", "Aswan", "Damietta", "Damanhur", "Minya", "Beni Suef", "Qena", "Sohag", "Hurghada", "6th of October City", "Shibin El Kom", "Banha", "Kafr El Sheikh", "Arish", "Mallawi", "10th of Ramadan City", "Bilbeis"] },
        { name: "Nigeria", code: "ng", cities: ["Lagos", "Kano", "Ibadan", "Kaduna", "Port Harcourt", "Benin City", "Maiduguri", "Zaria", "Aba", "Jos", "Ilorin", "Oyo", "Enugu", "Abeokuta", "Abuja", "Sokoto", "Onitsha", "Warri", "Ebute Ikorodu", "Okene", "Calabar", "Katsina", "Akure", "Ogbomosho", "Bauchi", "Iseyin", "Minna", "Makurdi", "Owo", "Ado Ekiti"] },
        { name: "Bangladesh", code: "bd", cities: ["Dhaka", "Chittagong", "Khulna", "Rajshahi", "Comilla", "Shyampur", "Barisal", "Tongi", "Sylhet", "Narayanganj", "Bogra", "Dinajpur", "Mymensingh", "Jessore", "Rangpur", "Gazipur", "Savar", "Cox's Bazar", "Brahmanbaria", "Narsingdi", "Tangail", "Jamalpur", "Pabna", "Noakhali", "Feni", "Sirajganj", "Faridpur", "Chandpur", "Lakshmipur", "Kushtina", "Kushtina"] },
        { name: "Mexico", code: "mx", cities: ["Mexico City", "Ecatepec", "Guadalajara", "Puebla", "Ciudad Juárez", "Tijuana", "León", "Zapopan", "Monterrey", "Nezahualcóyotl", "Chihuahua", "Naucalpan", "Mérida", "San Luis Potosí", "Aguascalientes", "Hermosillo", "Saltillo", "Mexicali", "Culiacán", "Guadalupe", "Acapulco", "Tlalnepantla", "Cancún", "Querétaro", "Chimalhuacán", "Torreón", "Morelia", "Reynosa", "Tlaquepaque", "Cancun", "Tuxtla Gutiérrez"] },
        { name: "Philippines", code: "ph", cities: ["Quezon City", "Manila", "Davao City", "Caloocan", "Cebu City", "Zamboanga City", "Taguig", "Antipolo", "Pasig", "Cagayan de Oro", "Parañaque", "Dasmariñas", "Valenzuela", "Bacoor", "General Santos", "Las Piñas", "Makati", "San Jose del Monte", "Bacolod", "Muntinlupa", "Calamba", "Marikina", "Iloilo City", "Pasay", "Angeles", "Lapu-Lapu City", "Imus", "Mandaluyong", "Malabon", "Mandaue"] },
        { name: "Vietnam", code: "vn", cities: ["Ho Chi Minh City", "Hanoi", "Da Nang", "Hai Phong", "Can Tho", "Bien Hoa", "Nha Trang", "Hue", "Buon Ma Thuot", "Vung Tau", "Quy Nhon", "Long Xuyen", "Thai Nguyen", "Vinh", "Rach Gia", "Phan Thiet", "Ha Long", "Da Lat", "Nam Dinh", "My Tho", "Soc Trang", "Pleiku", "Thanh Hoa", "Ca Mau", "Bac Lieu", "Yen Bai", "Hoa Binh", "Viet Tri", "Dong Hoi", "Vinh Yen"] },
        { name: "Thailand", code: "th", cities: ["Bangkok", "Nonthaburi", "Nakhon Ratchasima", "Chiang Mai", "Hat Yai", "Udon Thani", "Pak Kret", "Khon Kaen", "Chaophraya Surasak", "Ubon Ratchathani", "Nakhon Si Thammarat", "Nakhon Sawan", "Nakhon Pathom", "Phitsanulok", "Pattaya", "Songkhla", "Surat Thani", "Rangsit", "Yala", "Phuket", "Samut Prakan", "Lampang", "Laem Chabang", "Chiang Rai", "Trang", "Phra Nakhon Si Ayutthaya", "Ko Samui", "Samut Sakhon", "Rayong", "Mae Sot"] }
    ];
};

export const getCitiesByCountry = async (countryName: string): Promise<string[]> => {
    const countries = await getCountries();
    const country = countries.find(c => c.name === countryName);
    return country ? country.cities : [];
};

// --- Client Features: Favorites & Consultation Log ---

export const toggleFavorite = async (clientId: string, lawyerId: string, lawyerName: string): Promise<boolean> => {
    const favRef = doc(db, 'favorites', `${clientId}-${lawyerId}`);
    const favSnap = await getDoc(favRef);

    if (favSnap.exists()) {
        await deleteDoc(favRef);
        return false; 
    } else {
        const favorite: Favorite = {
            id: `${clientId}-${lawyerId}`,
            clientId,
            lawyerId,
            savedAt: new Date().toISOString(),
        };
        await setDoc(favRef, favorite);
        await logConsultation(clientId, lawyerId, lawyerName, 'favorite'); 
        return true; 
    }
};

export const checkIfFavorite = async (clientId: string, lawyerId: string): Promise<boolean> => {
    if (!clientId || !lawyerId) return false;
    const favRef = doc(db, 'favorites', `${clientId}-${lawyerId}`);
    const favSnap = await getDoc(favRef);
    return favSnap.exists();
};

export const getFavorites = async (clientId: string): Promise<LawyerProfile[]> => {
    try {
        const q = query(collection(db, 'favorites'), where('clientId', '==', clientId), orderBy('savedAt', 'desc'));
        const querySnapshot = await getDocs(q);
        
        const favoriteLawyerIds = querySnapshot.docs.map(doc => (doc.data() as Favorite).lawyerId);
        
        if (favoriteLawyerIds.length === 0) return [];

        const lawyerProfiles: LawyerProfile[] = [];
        for (const lawyerId of favoriteLawyerIds) {
            const profile = await getLawyerProfile(lawyerId);
            if (profile) {
                lawyerProfiles.push(profile);
            }
        }
        return lawyerProfiles;

    } catch (error) {
        console.error("Error getting favorites:", error);
        throw error; 
    }
};

export const logConsultation = async (clientId: string, lawyerId: string, lawyerName: string, method: ConsultationLog['contactMethod']) => {
    try {
        const logId = `${clientId}-${lawyerId}-${Date.now()}`;
        const logEntry: ConsultationLog = {
            id: logId,
            clientId,
            lawyerId,
            lawyerName,
            contactMethod: method,
            contactedAt: new Date().toISOString(),
        };
        await setDoc(doc(db, 'consultations', logId), logEntry);
    } catch (error) {
        console.error("Error logging consultation:", error);
        throw error;
    }
};

export const getClientConsultationHistory = async (clientId: string): Promise<ConsultationLog[]> => {
    try {
        const q = query(collection(db, 'consultations'), where('clientId', '==', clientId), orderBy('contactedAt', 'desc'));
        const querySnapshot = await getDocs(q);
        const history: ConsultationLog[] = [];
        querySnapshot.forEach(doc => {
            history.push(doc.data() as ConsultationLog);
        });
        return history;
    } catch (error) {
        console.error("Error getting client consultation history:", error);
        throw error; 
    }
};