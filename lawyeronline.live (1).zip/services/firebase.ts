import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyDKV1EnDaIf67WFvhpj73xXSc9L-mKWS5E",
  authDomain: "jurisconnect-wwep2.firebaseapp.com",
  projectId: "jurisconnect-wwep2",
  storageBucket: "jurisconnect-wwep2.firebasestorage.app",
  messagingSenderId: "525233484348",
  appId: "1:525233484348:web:1049b0ad988d207ad00939",
  measurementId: "G-2TYR4EP2YJ"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
export const storage = getStorage(app);