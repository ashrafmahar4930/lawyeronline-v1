
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateArticle = async (topic: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a professional legal article about: ${topic}. Format it with Markdown headers and paragraphs. Keep it under 500 words.`,
    });
    return response.text || "No content generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Failed to generate article.";
  }
};

export const generateLegalDocument = async (docType: string, details: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Draft a legal document of type: "${docType}". 
      Here are the specific details: "${details}".
      
      Ensure the language is formal, legally sound, and formatted correctly for a legal document. 
      Do not include placeholders, fill in the provided details.`,
    });
    return response.text || "No document generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Failed to generate document.";
  }
};
