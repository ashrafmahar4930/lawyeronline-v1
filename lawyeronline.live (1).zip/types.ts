

export type UserRole = 'admin' | 'lawyer' | 'client';

export interface User {
  uid: string;
  email: string;
  role: UserRole;
  displayName?: string;
  photoURL?: string;
}

export interface LawyerProfile {
  uid: string; // Links to User/Firebase ID
  fullName: string;
  title: string; // e.g., Advocate, Barrister
  specialties: string[]; // Changed from single string to array
  country: string;
  city: string;
  officeName: string;
  officeAddress: string;
  contactMobile: string;
  contactWhatsapp: string;
  contactEmail: string;
  socialMediaLink?: string;
  degreeName: string;
  issuingAuthority: string;
  licenseNumber: string;
  aboutMe: string;
  achievements: string;
  isVerified: boolean;
  verificationStatus: 'none' | 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  picture?: string;
  rating?: number; // Added for UI cards
  reviewCount?: number; // Added for UI cards
  // New textual verification fields (replacing document uploads)
  enrollmentOrRollNumber?: string;
  yearOfGraduation?: string;
  barCouncilName?: string;
}

export interface Review {
  id: string;
  lawyerId: string;
  clientId: string;
  clientName: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  lawyerId: string;
  lawyerName: string; // For client display
  clientId: string;
  clientName: string;
  clientEmail: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  status: 'pending' | 'confirmed' | 'rejected';
  notes: string;
  createdAt: string;
}

export interface ImportantDate {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD format
  notes?: string;
}

export interface CaseFile {
  id: string;
  name: string;
  url: string;
  uploadedAt: string; // ISO string
}

export interface Case {
  id: string;
  lawyerId: string;
  clientName: string;
  caseTitle: string;
  courtName: string;
  nextHearingDate: string; // YYYY-MM-DD
  stage: string; // e.g., Filing, Hearing, Evidence, Verdict
  notes: string; // Existing notes field, now for general case notes
  // New fields for enhanced case management
  description?: string;
  opposingCounsel?: string;
  status: 'Open' | 'Closed' | 'On Hold'; // Overall case status
  importantDates: ImportantDate[];
  caseFiles: CaseFile[];
}

export interface KhataEntry {
  id: string;
  caseId: string;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  nextPaymentDueDate: string;
  description: string;
}

export interface VerificationRequest {
  id: string;
  lawyerId: string;
  lawyerName: string;
  lawyerEmail: string; // Added to match admin's need
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  // Textual details for verification (replacing document URLs)
  degreeName: string;
  issuingAuthority: string;
  licenseNumber: string;
  enrollmentOrRollNumber: string;
  yearOfGraduation: string;
  barCouncilName: string;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  description: string; // Added to match DB
  author: string;
  date: string; // Mapped from createdAt/updatedAt
  featuredImage?: string; // Changed from imageUrl to match DB
  slug: string; // New field for URL-friendly identifier
}

export interface Country {
  name: string;
  code: string;
  cities: string[];
}

export interface City {
  name: string;
}

export interface Favorite {
  id: string; // client_uid-lawyer_uid
  clientId: string;
  lawyerId: string;
  savedAt: string;
}

export interface ConsultationLog {
  id: string; // client_uid-lawyer_uid-timestamp
  clientId: string;
  lawyerId: string;
  contactMethod: 'whatsapp' | 'call' | 'email' | 'favorite';
  contactedAt: string;
  lawyerName: string; // For display in client dashboard
}