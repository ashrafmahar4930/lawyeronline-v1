import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { User, UserRole } from './types';
import { auth } from './services/firebase';
import { getUserRole, subscribeToAppLogo, DEFAULT_LOGO_SVG } from './services/mockDataService';
import { onAuthStateChanged, signOut, setPersistence, browserLocalPersistence } from 'firebase/auth';

// Pages
import Home from './pages/Home';
import AuthPage from './pages/Auth';
import LawyerDashboard from './pages/LawyerDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ClientDashboard from './pages/ClientDashboard';
import FindLawyers from './pages/FindLawyers';
import ArticleDetails from './pages/ArticleDetails';
import LawyerProfilePage from './pages/LawyerProfilePage';
import { PrivacyPolicy, TermsOfService, Disclaimer } from './pages/LegalPages'; 
import Navbar from './components/Navbar';

// Auth Context
interface AuthContextType {
  user: User | null;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => useContext(AuthContext);

// Error Boundary Component
interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = { hasError: false, error: null };
  // Explicitly declare props to avoid TypeScript error
  public props: ErrorBoundaryProps;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.props = props;
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-red-50 p-4">
          <div className="bg-white p-8 rounded-lg shadow-xl border border-red-100 max-w-lg text-center">
            <svg className="w-16 h-16 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            <h1 className="text-2xl font-bold text-red-700 mb-2">Something went wrong</h1>
            <p className="text-slate-600 mb-4">We encountered an unexpected error. Please try refreshing the page.</p>
            <button onClick={() => window.location.reload()} className="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700 transition">Refresh Page</button>
            {this.state.error && <pre className="mt-6 p-4 bg-slate-100 rounded text-left text-xs text-slate-500 overflow-auto max-h-40">{this.state.error.toString()}</pre>}
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles: UserRole[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (!allowedRoles.includes(user.role)) return <Navigate to="/" replace />;
  return <>{children}</>;
};

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [appLogoUrl, setAppLogoUrl] = useState<string | null>(null); // State for app logo in footer

  useEffect(() => {
    const setupAuthPersistence = async () => {
      // Explicitly set persistence to LOCAL to ensure session lasts across browser restarts/page reloads
      await setPersistence(auth, browserLocalPersistence);

      const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        if (firebaseUser) {
          let role = await getUserRole(firebaseUser.uid);
          
          // Admin check: using the requested admin email
          if (firebaseUser.email === 'admin@jurisconnect.com') {
            role = 'admin';
          }

          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email || '',
            role: (role as UserRole) || 'client',
            displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0],
            photoURL: firebaseUser.photoURL || undefined
          });
        } else {
          setUser(null);
        }
        setIsLoading(false);
      });

      return () => unsubscribe();
    };

    setupAuthPersistence();
  }, []);

  // Subscribe to App Logo changes for the footer
  useEffect(() => {
    const unsubscribe = subscribeToAppLogo((url) => {
        setAppLogoUrl(url);
    });
    return () => unsubscribe();
  }, []);


  const logout = () => {
    signOut(auth);
    setUser(null);
  };

  return (
    <ErrorBoundary>
      <AuthContext.Provider value={{ user, logout, isLoading }}>
        <HashRouter>
          <ScrollToTop />
          <div className="min-h-screen bg-blue-50 text-slate-900 flex flex-col font-sans">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<AuthPage isLogin={true} />} />
                <Route path="/signup" element={<AuthPage isLogin={false} />} />
                <Route path="/find-lawyers" element={<FindLawyers />} />
                <Route path="/articles/:slug" element={<ArticleDetails />} />
                <Route path="/lawyer/:uid" element={<LawyerProfilePage />} />
                
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
                <Route path="/disclaimer" element={<Disclaimer />} />
                
                <Route path="/dashboard/lawyer" element={
                  <ProtectedRoute allowedRoles={['lawyer', 'admin']}>
                    <LawyerDashboard />
                  </ProtectedRoute>
                } />
                
                <Route path="/dashboard/admin" element={
                  <ProtectedRoute allowedRoles={['admin']}>
                    <AdminDashboard />
                  </ProtectedRoute>
                } />
                
                <Route path="/dashboard/client" element={
                  <ProtectedRoute allowedRoles={['client', 'admin']}>
                    <ClientDashboard />
                  </ProtectedRoute>
                } />
              </Routes>
            </main>
            <footer className="bg-blue-950 text-blue-100 py-10 border-t-4 border-amber-500">
              <div className="container mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-8 text-xs">
                <div className="col-span-2 md:col-span-1">
                  <h3 className="text-base font-bold text-white mb-3 font-serif tracking-wide flex items-center gap-2">
                    {/* Dynamic Logo in Footer */}
                    {appLogoUrl ? (
                        <img 
                            src={appLogoUrl} 
                            alt="LawyerOnline Logo" 
                            className="h-8 w-auto object-contain" // Adjusted for footer
                            onError={(e) => {
                                e.currentTarget.onerror = null; // Prevent loop
                                setAppLogoUrl(null); // Switch to fallback render
                            }}
                        />
                    ) : (
                        <img 
                            src={DEFAULT_LOGO_SVG} 
                            alt="LawyerOnline Logo" 
                            className="h-8 w-auto object-contain" // Adjusted for footer
                        />
                    )}
                    <span>LawyerOnline<span className="text-red-500">.LIVE</span></span>
                  </h3>
                  <p className="opacity-80 leading-relaxed max-w-xs text-blue-200">Connecting justice seekers with verified legal experts worldwide. Effective, Secure, Real-time.</p>
                </div>
                <div>
                  <h4 className="font-bold text-amber-500 mb-3 uppercase tracking-wider text-[11px]">Platform</h4>
                  <ul className="space-y-2 opacity-90">
                    <li><Link to="/find-lawyers" className="hover:text-amber-400 transition">Find Lawyers</Link></li>
                    <li><Link to="/" className="hover:text-amber-400 transition">Our Team</Link></li>
                    <li><Link to="/" className="hover:text-amber-400 transition">Articles</Link></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-amber-500 mb-3 uppercase tracking-wider text-[11px]">Legal & Access</h4>
                  <ul className="space-y-2 opacity-90">
                    <li><Link to="/privacy" className="hover:text-amber-400 transition">Privacy Policy</Link></li>
                    <li><Link to="/terms" className="hover:text-amber-400 transition">Terms of Service</Link></li>
                    <li><Link to="/disclaimer" className="hover:text-amber-400 transition">Disclaimer</Link></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-amber-500 mb-3 uppercase tracking-wider text-[11px]">Contact</h4>
                  <div className="opacity-90 space-y-2">
                    <p>Email: <a href="mailto:adittamahar@gmail.com" className="hover:text-amber-400 transition">adittamahar@gmail.com</a></p>
                    <p>WhatsApp: <a href="https://wa.me/03000653541" target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition">03000653541</a></p>
                  </div>
                </div>
              </div>
              <div className="text-center mt-8 pt-6 border-t border-blue-900 text-[10px] text-blue-400 flex flex-col md:flex-row justify-center gap-2 md:gap-6">
                <span>&copy; {new Date().getFullYear()} LawyerOnline.LIVE. All rights reserved.</span>
                <span className="hidden md:inline">|</span>
                <Link to="/privacy" className="hover:text-amber-400">Privacy Policy</Link>
                <span className="hidden md:inline">|</span>
                <Link to="/terms" className="hover:text-amber-400">Terms</Link>
              </div>
            </footer>
          </div>
        </HashRouter>
      </AuthContext.Provider>
    </ErrorBoundary>
  );
}